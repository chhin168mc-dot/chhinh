import math
import random

from PySide6.QtCore import (Property, QAbstractAnimation, QEasingCurve, QPointF, QPropertyAnimation, QRectF, Qt,
                            QTimer, QVariantAnimation)
from PySide6.QtGui import (QColor, QLinearGradient, QPainter, QPainterPath, QPen, QRadialGradient)
from PySide6.QtWidgets import QGraphicsOpacityEffect, QPushButton, QStackedWidget, QWidget

from .theme import ACCENT

AA = QPainter.RenderHint.Antialiasing


def lerp_color(a: QColor, b: QColor, t: float) -> QColor:
    return QColor(int(a.red() + (b.red() - a.red()) * t), int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t), int(a.alpha() + (b.alpha() - a.alpha()) * t))


# ---------------------------------------------------------------- Background App
class AnimatedBackground(QWidget):
    """Dark gradient + drifting embers + moving glow. set_boost(1) speeds it up during downloads."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.boost, self._target, self._t = 0.0, 0.0, 0.0
        self._p = [self._particle(True) for _ in range(70)]
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)

    def _particle(self, anywhere=False):
        w, h = max(self.width(), 1100), max(self.height(), 680)
        return {"x": random.uniform(0, w), "y": random.uniform(0, h) if anywhere else h + 10,
                "r": random.uniform(1, 3.2), "v": random.uniform(12, 40),
                "a": random.uniform(0.25, 0.8), "ph": random.uniform(0, 6.28)}

    def set_boost(self, v: float):
        self._target = v

    def _tick(self):
        dt = 0.016
        self._t += dt
        self.boost += (self._target - self.boost) * 0.05
        for p in self._p:
            p["y"] -= p["v"] * dt * (1 + self.boost * 3)
            p["x"] += math.sin(self._t + p["ph"]) * 10 * dt
            if p["y"] < -10:
                p.update(self._particle())
        self.update()

    def paintEvent(self, _e):
        g = QPainter(self)
        g.setRenderHint(AA)
        w, h = self.width(), self.height()
        bg = QLinearGradient(0, 0, 0, h)
        bg.setColorAt(0, QColor("#0b0b0c"))
        bg.setColorAt(1, QColor("#1d1d20"))
        g.fillRect(self.rect(), bg)

        cx = w * (0.5 + 0.35 * math.sin(self._t * 0.25))
        glow = QRadialGradient(cx, h * 0.95, h * 0.85)
        c = QColor(ACCENT)
        c.setAlphaF(0.12 + 0.12 * self.boost)
        glow.setColorAt(0, c)
        c.setAlphaF(0)
        glow.setColorAt(1, c)
        g.fillRect(self.rect(), glow)

        g.setPen(Qt.PenStyle.NoPen)
        for p in self._p:
            c = QColor(ACCENT)
            c.setAlphaF(max(0.0, p["a"] * (0.5 + 0.5 * math.sin(self._t * 2 + p["ph"]))))
            g.setBrush(c)
            g.drawEllipse(QPointF(p["x"], p["y"]), p["r"], p["r"])
        g.end()


# ---------------------------------------------------------------- Click on App
class RippleOverlay(QWidget):
    """Expanding ring wherever the user clicks. Transparent to the mouse."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._items = []

    def ripple(self, pos):
        item = {"pos": QPointF(pos), "t": 0.0}
        anim = QVariantAnimation(self)
        anim.setDuration(650)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.valueChanged.connect(lambda v: (item.__setitem__("t", v), self.update()))
        anim.finished.connect(lambda: (self._items.remove(item) if item in self._items else None, self.update()))
        self._items.append(item)
        anim.start(QAbstractAnimation.DeletionPolicy.DeleteWhenStopped)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        for it in self._items:
            t = it["t"]
            r = 8 + 80 * t
            ring = QColor(ACCENT)
            ring.setAlphaF(0.65 * (1 - t))
            fill = QColor(ACCENT)
            fill.setAlphaF(0.18 * (1 - t))
            p.setPen(QPen(ring, 2))
            p.setBrush(fill)
            p.drawEllipse(it["pos"], r, r)
        p.end()


# ---------------------------------------------------------------- Logo (open animation)
class LogoWidget(QWidget):
    def __init__(self, pixmap, size=150, parent=None):
        super().__init__(parent)
        self.pix, self._s, self._ph = pixmap, 0.0, 0.0
        self.setFixedSize(size, size)
        t = QTimer(self)
        t.timeout.connect(self._breathe)
        t.start(30)

    def _breathe(self):
        self._ph += 0.05
        self.update()

    def _gs(self):
        return self._s

    def _ss(self, v):
        self._s = v
        self.update()

    logoScale = Property(float, _gs, _ss)

    def play_intro(self):
        a = QPropertyAnimation(self, b"logoScale", self)
        a.setDuration(900)
        a.setStartValue(0.0)
        a.setEndValue(1.0)
        a.setEasingCurve(QEasingCurve.Type.OutBack)
        a.start(QAbstractAnimation.DeletionPolicy.DeleteWhenStopped)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        w, h = self.width(), self.height()
        s = self._s * (1 + 0.025 * math.sin(self._ph))
        p.translate(w / 2, h / 2)
        p.scale(s, s)
        p.translate(-w / 2, -h / 2)
        glow = QRadialGradient(w / 2, h / 2, w * 0.62)
        c = QColor(ACCENT)
        c.setAlphaF(0.30 + 0.12 * math.sin(self._ph))
        glow.setColorAt(0.6, c)
        c.setAlphaF(0)
        glow.setColorAt(1, c)
        p.fillRect(self.rect(), glow)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()).adjusted(12, 12, -12, -12), 20, 20)
        p.setClipPath(path)
        p.drawPixmap(QRectF(self.rect()).adjusted(12, 12, -12, -12).toRect(), self.pix)
        p.end()


# ---------------------------------------------------------------- Download animation
class ShimmerProgressBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._shown, self._phase, self._text = 0.0, 0.0, ""
        self.setFixedHeight(24)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._step)
        self._anim = QPropertyAnimation(self, b"shown", self)
        self._anim.setDuration(260)

    def _step(self):
        self._phase = (self._phase + 0.015) % 1.0
        self.update()

    def showEvent(self, e):
        self._timer.start(16)
        super().showEvent(e)

    def hideEvent(self, e):
        self._timer.stop()
        super().hideEvent(e)

    def _gs(self):
        return self._shown

    def _ss(self, v):
        self._shown = v
        self.update()

    shown = Property(float, _gs, _ss)

    def setValue(self, v, text=None, immediate=False):
        if text is not None:
            self._text = text
        if immediate:
            self._anim.stop()
            self._ss(float(v))
            return
        self._anim.stop()
        self._anim.setStartValue(self._shown)
        self._anim.setEndValue(float(v))
        self._anim.start()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        rad = r.height() / 2
        p.setPen(QPen(QColor(255, 255, 255, 40), 1))
        p.setBrush(QColor(255, 255, 255, 24))
        p.drawRoundedRect(r, rad, rad)
        w = r.width() * max(0.0, min(100.0, self._shown)) / 100
        if w > 2:
            fr = QRectF(r.left(), r.top(), w, r.height())
            g = QLinearGradient(fr.left(), 0, fr.right(), 0)
            g.setColorAt(0, QColor("#ff9a3a"))
            g.setColorAt(1, QColor(ACCENT))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(g)
            p.drawRoundedRect(fr, rad, rad)
            p.save()
            clip = QPainterPath()
            clip.addRoundedRect(fr, rad, rad)
            p.setClipPath(clip)
            sx = fr.left() - 120 + self._phase * (fr.width() + 120)
            sg = QLinearGradient(sx, 0, sx + 120, 0)
            sg.setColorAt(0, QColor(255, 255, 255, 0))
            sg.setColorAt(0.5, QColor(255, 255, 255, 120))
            sg.setColorAt(1, QColor(255, 255, 255, 0))
            p.fillRect(fr, sg)
            p.restore()
        p.setPen(QColor("white"))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, f"{self._text}  {int(self._shown)}%".strip())
        p.end()


# ---------------------------------------------------------------- Buttons
class NokorButton(QPushButton):
    click_hook = None           # set by the main window: plays button.ogg

    def __init__(self, text, primary=False, parent=None):
        super().__init__(text, parent)
        self.primary, self._h = primary, 0.0
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(44)
        self._anim = QPropertyAnimation(self, b"hover", self)
        self._anim.setDuration(160)

    def _gh(self):
        return self._h

    def _sh(self, v):
        self._h = v
        self.update()

    hover = Property(float, _gh, _sh)

    def _go(self, to):
        self._anim.stop()
        self._anim.setStartValue(self._h)
        self._anim.setEndValue(to)
        self._anim.start()

    def enterEvent(self, e):
        self._go(1.0)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._go(0.0)
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if NokorButton.click_hook and self.isEnabled():
            NokorButton.click_hook()
        super().mousePressEvent(e)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(2, 3, -2, -2)
        r.translate(0, -1.5 * self._h)
        on = self.isEnabled()
        if self.primary:
            col = lerp_color(QColor(ACCENT), QColor("#ff7a50"), self._h)
            p.setPen(Qt.PenStyle.NoPen)
        else:
            col = QColor(255, 255, 255, int(18 + 34 * self._h))
            p.setPen(QPen(QColor(255, 255, 255, int(40 + 60 * self._h)), 1))
        if not on:
            col.setAlpha(col.alpha() // 3)
        if self.primary and on:                                   # glow under primary button
            gl = QColor(ACCENT)
            gl.setAlphaF(0.10 + 0.25 * self._h)
            p.save()
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(gl)
            p.drawRoundedRect(r.adjusted(-3, -2, 3, 5), 14, 14)
            p.restore()
        p.setBrush(col)
        p.drawRoundedRect(r, 11, 11)
        p.setPen(QColor("white") if on else QColor(255, 255, 255, 90))
        p.setFont(self.font())
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, self.text())
        p.end()


class FadeStack(QStackedWidget):
    """Stacked pages with a fade transition."""

    def go(self, index):
        if index == self.currentIndex():
            return
        self.setCurrentIndex(index)
        w = self.currentWidget()
        eff = QGraphicsOpacityEffect(w)
        w.setGraphicsEffect(eff)
        a = QPropertyAnimation(eff, b"opacity", w)
        a.setDuration(280)
        a.setStartValue(0.0)
        a.setEndValue(1.0)
        a.finished.connect(lambda: w.setGraphicsEffect(None))
        a.start(QAbstractAnimation.DeletionPolicy.DeleteWhenStopped)
