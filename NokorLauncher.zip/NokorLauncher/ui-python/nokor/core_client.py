import json
import shutil

from PySide6.QtCore import QObject, QProcess, QProcessEnvironment, Signal

from .config import CORE_DLL, CORE_EXE


class CoreJob(QObject):
    """Runs the C# core (dotnet NokorLauncher.Core.dll <cmd> ...) and parses its JSON-lines output."""
    message = Signal(dict)
    finished = Signal(int)

    def __init__(self, args, env=None, parent=None):
        super().__init__(parent)
        self._buf = b""
        self._done = False
        self.p = QProcess(self)
        self.p.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        if env:
            e = QProcessEnvironment.systemEnvironment()
            for k, v in env.items():
                e.insert(k, v)
            self.p.setProcessEnvironment(e)
        if CORE_EXE.exists():
            self.p.setProgram(str(CORE_EXE))
            self.p.setArguments(list(args))
        else:
            self.p.setProgram(shutil.which("dotnet") or "dotnet")
            self.p.setArguments([str(CORE_DLL)] + list(args))
        self.p.readyReadStandardOutput.connect(self._read)
        self.p.errorOccurred.connect(self._err)
        self.p.finished.connect(lambda code, _s: self._finish(code))

    def start(self):
        self.p.start()

    def _finish(self, code):
        if self._buf.strip():
            self._line(self._buf)
        if not self._done:
            self._done = True
            self.finished.emit(code)

    def _err(self, e):
        if e == QProcess.ProcessError.FailedToStart:
            self.message.emit({"type": "error", "message": "Cannot start the C# core. Is .NET 8 installed and build_all run?"})
            self._finish(-1)

    def _read(self):
        self._buf += bytes(self.p.readAllStandardOutput())
        *lines, self._buf = self._buf.split(b"\n")
        for ln in lines:
            self._line(ln)

    def _line(self, raw):
        text = raw.decode("utf-8", "replace").strip()
        if not text:
            return
        try:
            self.message.emit(json.loads(text))
        except json.JSONDecodeError:
            self.message.emit({"type": "log", "line": text})
