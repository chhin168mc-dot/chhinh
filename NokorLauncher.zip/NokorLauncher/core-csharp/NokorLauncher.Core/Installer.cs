using System.Diagnostics;
using System.Text.Json.Nodes;

namespace NokorLauncher.Core;

public sealed class Installer
{
    public static readonly HttpClient Http = CreateHttp();
    const string ManifestUrl = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

    static HttpClient CreateHttp()
    {
        var h = new HttpClient { Timeout = TimeSpan.FromMinutes(5) };
        h.DefaultRequestHeaders.UserAgent.ParseAdd("NokorLauncher/20.26.1.0 (com.nokorlauncher.mc)");
        return h;
    }

    readonly string root;
    public Installer(string root) { this.root = root; }

    sealed record Job(string Url, string Dest, string? Sha1, long Size, bool Optional);

    public static async Task ListVersionsAsync()
    {
        var m = JsonNode.Parse(await Http.GetStringAsync(ManifestUrl))!;
        var items = m["versions"]!.AsArray()
            .Select(v => new { id = (string)v!["id"]!, type = (string)v["type"]!, releaseTime = (string)v["releaseTime"]! })
            .ToList();
        Out.Emit(new { type = "versions", latestRelease = (string?)m["latest"]?["release"], items });
    }

    async Task EnsureVersionJsonAsync(string id)
    {
        var jp = Path.Combine(root, "versions", id, id + ".json");
        if (!File.Exists(jp))
        {
            var m = JsonNode.Parse(await Http.GetStringAsync(ManifestUrl))!;
            var e = m["versions"]!.AsArray().FirstOrDefault(x => (string?)x!["id"] == id)
                    ?? throw new Exception($"Unknown Minecraft version '{id}'");
            Directory.CreateDirectory(Path.GetDirectoryName(jp)!);
            await File.WriteAllTextAsync(jp, await Http.GetStringAsync((string)e["url"]!));
        }
        var parent = (string?)JsonNode.Parse(File.ReadAllText(jp))!["inheritsFrom"];
        if (parent != null) await EnsureVersionJsonAsync(parent);
    }

    public async Task InstallAsync(string id)
    {
        Directory.CreateDirectory(root);
        await EnsureVersionJsonAsync(id);
        var v = VersionData.Load(root, id);
        var jarId = (string)v["_jar"]!;
        var jobs = new List<Job>();

        var client = v["downloads"]?["client"];
        if (client != null)
            jobs.Add(new Job((string)client["url"]!, Path.Combine(root, "versions", jarId, jarId + ".jar"),
                (string?)client["sha1"], (long?)client["size"] ?? 0, false));

        foreach (var l in VersionData.Libraries(v))
            if (l.Url != null)
                jobs.Add(new Job(l.Url, Path.Combine(root, "libraries", l.Path), l.Sha1, l.Size, l.Sha1 == null));

        if (v["assetIndex"] is JsonNode ai)
        {
            var idxPath = Path.Combine(root, "assets", "indexes", (string)ai["id"]! + ".json");
            await Fetch(new Job((string)ai["url"]!, idxPath, (string?)ai["sha1"], (long?)ai["size"] ?? 0, false), _ => { });
            var objects = JsonNode.Parse(File.ReadAllText(idxPath))!["objects"]!.AsObject();
            foreach (var (_, o) in objects)
            {
                var h = (string)o!["hash"]!;
                var sub = h[..2];
                jobs.Add(new Job($"https://resources.download.minecraft.net/{sub}/{h}",
                    Path.Combine(root, "assets", "objects", sub, h), h, (long?)o["size"] ?? 0, false));
            }
        }

        long total = jobs.Sum(j => Math.Max(j.Size, 1)), done = 0;
        var sw = Stopwatch.StartNew();
        long lastEmit = -1000;
        void Add(long n)
        {
            var d = Interlocked.Add(ref done, n);
            var now = sw.ElapsedMilliseconds;
            if (now - Interlocked.Read(ref lastEmit) < 150) return;
            Interlocked.Exchange(ref lastEmit, now);
            Out.Emit(new { type = "progress", percent = Math.Min(100.0, 100.0 * d / total), done = d, total });
        }

        await Parallel.ForEachAsync(jobs, new ParallelOptions { MaxDegreeOfParallelism = 16 },
            async (j, _) => await Fetch(j, Add));

        Out.Emit(new { type = "progress", percent = 100.0, done = total, total });
        File.WriteAllText(Path.Combine(root, "versions", id, ".nokor_ok"), "20.26.1.0");
    }

    static async Task Fetch(Job j, Action<long> add)
    {
        if (File.Exists(j.Dest) && (j.Sha1 == null || Hasher.Sha1File(j.Dest).Equals(j.Sha1, StringComparison.OrdinalIgnoreCase)))
        {
            add(Math.Max(j.Size, 1));
            return;
        }
        Directory.CreateDirectory(Path.GetDirectoryName(j.Dest)!);
        for (int attempt = 1; attempt <= 3; attempt++)
        {
            long got = 0;
            var tmp = j.Dest + ".part";
            try
            {
                using var resp = await Http.GetAsync(j.Url, HttpCompletionOption.ResponseHeadersRead);
                resp.EnsureSuccessStatusCode();
                await using (var s = await resp.Content.ReadAsStreamAsync())
                await using (var f = File.Create(tmp))
                {
                    var buf = new byte[81920];
                    int n;
                    while ((n = await s.ReadAsync(buf)) > 0) { await f.WriteAsync(buf.AsMemory(0, n)); got += n; add(n); }
                }
                if (j.Sha1 != null && !Hasher.Sha1File(tmp).Equals(j.Sha1, StringComparison.OrdinalIgnoreCase))
                    throw new IOException("hash mismatch: " + j.Url);
                File.Move(tmp, j.Dest, true);
                return;
            }
            catch (Exception) when (attempt < 3)
            {
                add(-got);
                await Task.Delay(500 * attempt);
            }
            catch (Exception ex)
            {
                if (File.Exists(tmp)) File.Delete(tmp);
                if (j.Optional) { Out.Emit(new { type = "warn", message = $"skipped {Path.GetFileName(j.Dest)}: {ex.Message}" }); return; }
                throw;
            }
        }
    }
}
