#pragma once
#include <GLES2/gl2.h>

class Renderer {
public:
    Renderer(int w, int h);
    ~Renderer();

    void beginFrame();
    void endFrame();
    void drawCube(float x, float y, float z, float sx, float sy, float sz, float r, float g, float b);

private:
    int width, height;
    GLuint program;
    GLuint vbo;
    GLint posLoc, colorLoc, mvpLoc;

    void initShaders();
    void setupCube();
};
