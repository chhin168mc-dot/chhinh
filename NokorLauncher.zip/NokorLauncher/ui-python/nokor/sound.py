from PySide6.QtCore import QUrl
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer

from .config import SOUNDS


class SoundManager:
    """open.ogg / button.ogg / background.ogg from assets/sounds. Missing files are ignored."""

    def __init__(self, enabled=True, volume=0.6):
        self.enabled, self.volume = enabled, volume
        self._players = {}

    def _make(self, name, loop=False, gain=1.0):
        f = SOUNDS / name
        if not f.exists():
            return None
        player, out = QMediaPlayer(), QAudioOutput()
        out.setVolume(self.volume * gain)
        player.setAudioOutput(out)
        player.setSource(QUrl.fromLocalFile(str(f)))
        if loop:
            player.setLoops(QMediaPlayer.Loops.Infinite)
        player._out, player._gain = out, gain          # keep references alive
        return player

    def _get(self, name, loop=False, gain=1.0):
        if name not in self._players:
            self._players[name] = self._make(name, loop, gain)
        return self._players[name]

    def play(self, name):
        p = self._get(name) if self.enabled else None
        if p:
            p.stop()
            p.play()

    def start_background(self):
        p = self._get("background.ogg", loop=True, gain=0.45) if self.enabled else None
        if p:
            p.play()

    def configure(self, enabled, volume):
        self.enabled, self.volume = enabled, volume
        for p in self._players.values():
            if p:
                p._out.setVolume(volume * p._gain)
        bg = self._players.get("background.ogg")
        if bg:
            bg.play() if enabled else bg.pause()
        elif enabled:
            self.start_background()
