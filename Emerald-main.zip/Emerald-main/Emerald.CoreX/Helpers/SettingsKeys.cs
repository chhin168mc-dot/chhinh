using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emerald.CoreX.Helpers;

public static class SettingsKeys
{
    public const string SavedGames = "SavedGames";
    public const string BaseGameOptions = "BaseGameOptions";
    public const string Settings = "Settings";
    public const string MinecraftAccounts = "MinecraftAccounts";
    public const string SelectedMinecraftAccount = "SelectedMinecraftAccount";
    public const string ElyByAccounts = "ElyByAccounts";
    public const string StoreInstalledItems = "StoreInstalledItems";
    public const string StoreSharedContentSettings = "StoreSharedContentSettings";
    public const string PlaytimeHistory = "PlaytimeHistory";
    public const string SavedServers = "SavedServers";
    public const string HomePreferences = "HomePreferences";
    public const string QuickProfiles = "QuickProfiles";
}
