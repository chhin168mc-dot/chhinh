import hashlib
import json
import urllib.parse
import urllib.request
from pathlib import Path

from .config import USER_AGENT

API = "https://api.modrinth.com/v2"


def _get(url):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.load(r)


def search(query, kind, mc_version, loader):
    facets = [[f"project_type:{kind}"]]
    if mc_version:
        facets.append([f"versions:{mc_version}"])
    if kind == "mod" and loader:
        facets.append([f"categories:{loader}"])
    q = urllib.parse.urlencode({"query": query, "limit": 25, "facets": json.dumps(facets)})
    return _get(f"{API}/search?{q}")["hits"]


def download(project_id, kind, mc_version, loader, dest_dir, progress):
    params = {}
    if mc_version:
        params["game_versions"] = json.dumps([mc_version])
    if kind == "mod" and loader:
        params["loaders"] = json.dumps([loader])
    versions = _get(f"{API}/project/{project_id}/version?" + urllib.parse.urlencode(params))
    if not versions:
        raise RuntimeError("No compatible file for this Minecraft version")
    files = versions[0]["files"]
    f = next((x for x in files if x.get("primary")), files[0])

    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    target = dest / Path(f["filename"]).name                  # strip any path components
    tmp = target.with_suffix(target.suffix + ".part")
    sha1 = hashlib.sha1()
    req = urllib.request.Request(f["url"], headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as r, open(tmp, "wb") as out:
        total = int(r.headers.get("Content-Length") or f.get("size") or 0)
        got = 0
        while chunk := r.read(65536):
            out.write(chunk)
            sha1.update(chunk)
            got += len(chunk)
            if total:
                progress(got * 100 / total, f["filename"])
    expected = f.get("hashes", {}).get("sha1")
    if expected and sha1.hexdigest() != expected:
        tmp.unlink(missing_ok=True)
        raise RuntimeError("Checksum mismatch - download discarded")
    tmp.replace(target)
    return str(target)
