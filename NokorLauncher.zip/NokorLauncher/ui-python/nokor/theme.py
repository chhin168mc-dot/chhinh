ACCENT = "#ff5a36"

STYLE = """
* { font-family: 'Segoe UI','Noto Sans','Noto Sans Khmer','Khmer OS',sans-serif; color:#ececec; font-size:14px; }
QLabel { background: transparent; }
QLabel#h1 { font-size:28px; font-weight:700; }
QLabel#brand { font-size:16px; font-weight:700; letter-spacing:3px; }
QLabel#muted { color:#9a9a9f; }
QFrame#sidebar { background: rgba(0,0,0,0.38); border-right:1px solid rgba(255,255,255,0.06); }
QPushButton#banner { background: rgba(255,90,54,0.18); border:1px solid #ff5a36; border-radius:10px; padding:10px; text-align:left; }
QPushButton#winbtn { background:transparent; border:none; font-size:16px; padding:6px 12px; border-radius:6px; }
QPushButton#winbtn:hover { background: rgba(255,255,255,0.12); }
QLineEdit, QComboBox, QListWidget, QPlainTextEdit {
  background: rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.12);
  border-radius:8px; padding:6px 10px; selection-background-color:#ff5a36; }
QLineEdit:focus, QComboBox:focus { border:1px solid #ff5a36; }
QListWidget::item { padding:8px; border-radius:6px; }
QListWidget::item:hover { background: rgba(255,255,255,0.08); }
QListWidget::item:selected { background:#ff5a36; color:white; }
QComboBox QAbstractItemView { background:#1b1b1e; selection-background-color:#ff5a36; border:1px solid #333; }
QSlider::groove:horizontal { height:6px; background:rgba(255,255,255,0.15); border-radius:3px; }
QSlider::sub-page:horizontal { background:#ff5a36; border-radius:3px; }
QSlider::handle:horizontal { width:16px; margin:-5px 0; border-radius:8px; background:white; }
QCheckBox { spacing:8px; }
QCheckBox::indicator { width:18px; height:18px; border-radius:5px; border:1px solid #666; background:rgba(255,255,255,0.06); }
QCheckBox::indicator:checked { background:#ff5a36; border-color:#ff5a36; }
QScrollBar:vertical { background:transparent; width:10px; }
QScrollBar::handle:vertical { background:rgba(255,255,255,0.2); border-radius:5px; min-height:30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
QToolTip { background:#1b1b1e; color:white; border:1px solid #444; }
"""
