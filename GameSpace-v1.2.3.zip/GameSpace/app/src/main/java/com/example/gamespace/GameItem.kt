package com.example.gamespace

import android.graphics.Color
import android.graphics.drawable.Drawable

enum class ItemKind { GAME, APP, DEMO }

data class GameItem(
    val label: String,
    val packageName: String?,
    val icon: Drawable?,
    val kind: ItemKind,
    val colorA: Int,
    val colorB: Int
) {
    companion object {
        // ពណ៌ត្រជាក់ភ្នែក (cool palette) សម្រាប់ផ្ទៃកាត
        private val palette = listOf(
            "#0F4C75" to "#3282B8",
            "#0B6E79" to "#2EC4B6",
            "#1B3A6B" to "#5B86E5",
            "#134E5E" to "#4FB286",
            "#2C3E78" to "#6A82FB",
            "#0F5E6B" to "#38CFE0",
            "#233D72" to "#2CB5C9"
        )

        fun colorsFor(key: String): Pair<Int, Int> {
            val idx = (key.hashCode() and 0x7fffffff) % palette.size
            val (a, b) = palette[idx]
            return Color.parseColor(a) to Color.parseColor(b)
        }
    }
}
