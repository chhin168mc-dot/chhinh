package com.example.gamespace

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.os.SystemClock
import android.view.Choreographer
import android.widget.ImageView

/**
 * ចាក់ intro "open-app" (61 frame ដកស្រង់ពី GIF) ព្រមជាមួយសំឡេង gspace_open_sound.ogg។
 * Frame ត្រូវបានជ្រើសតាម "ទីតាំងសំឡេង" (MediaPlayer.currentPosition) ដូច្នេះរូប និងសំឡេងស៊ីគ្នា
 * ហើយដំណើរការលើគ្រប់ Android (GIF ធម្មតាមិនបង្ហាញជាចលនាលើ Android ចាស់ទេ)។
 */
class IntroPlayer(
    private val context: Context,
    private val view: ImageView,
    private val playSound: Boolean,
    private val onFinished: () -> Unit
) {
    private val res = context.resources
    private val durations: IntArray = res.getIntArray(R.array.intro_frame_ms)
    private val starts = IntArray(durations.size)
    private val totalMs: Int
    private val frameIds: IntArray

    private var player: MediaPlayer? = null
    private var bitmap: Bitmap? = null
    private var shown = -1
    private var startUptime = 0L
    private var running = false
    private var finished = false

    private val callback = Choreographer.FrameCallback { tick() }

    init {
        var acc = 0
        for (i in durations.indices) {
            starts[i] = acc
            acc += durations[i]
        }
        totalMs = acc
        frameIds = IntArray(durations.size) { i ->
            res.getIdentifier("intro_%03d".format(i), "drawable", context.packageName)
        }
    }

    fun start() {
        if (running || finished) return
        running = true
        showFrame(0)
        player = if (!playSound) null else try {
            MediaPlayer.create(context, R.raw.gspace_open_sound)
        } catch (e: Exception) {
            null
        }
        try {
            player?.start()
        } catch (e: Exception) {
            player = null
        }
        startUptime = SystemClock.uptimeMillis()
        Choreographer.getInstance().postFrameCallback(callback)
    }

    fun pause() {
        try {
            player?.pause()
        } catch (e: Exception) {
        }
    }

    fun resume() {
        if (!running) return
        try {
            player?.start()
        } catch (e: Exception) {
        }
    }

    fun release() {
        running = false
        Choreographer.getInstance().removeFrameCallback(callback)
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }

    private fun tick() {
        if (!running) return
        val p = player
        val audioPos: Int? = try {
            if (p != null && p.isPlaying) p.currentPosition else null
        } catch (e: Exception) {
            null
        }
        val pos = audioPos ?: (SystemClock.uptimeMillis() - startUptime).toInt()

        var idx = if (shown < 0) 0 else shown
        while (idx + 1 < starts.size && starts[idx + 1] <= pos) idx++
        if (idx != shown) showFrame(idx)

        val audioLen = try {
            p?.duration ?: 0
        } catch (e: Exception) {
            0
        }
        if (pos >= maxOf(totalMs, audioLen)) {
            finish()
        } else {
            Choreographer.getInstance().postFrameCallback(callback)
        }
    }

    private fun finish() {
        if (finished) return
        finished = true
        release()
        onFinished()
    }

    private fun showFrame(i: Int) {
        val id = frameIds[i]
        if (id == 0) return
        val opts = BitmapFactory.Options().apply {
            inMutable = true
            inBitmap = bitmap
        }
        var bmp: Bitmap? = try {
            BitmapFactory.decodeResource(res, id, opts)
        } catch (e: Exception) {
            null
        }
        if (bmp == null) {
            // inBitmap មិនត្រូវគ្នា → decode ថ្មី
            bmp = try {
                BitmapFactory.decodeResource(res, id)
            } catch (e: Exception) {
                null
            }
        }
        if (bmp != null) {
            bitmap = bmp
            view.setImageBitmap(bmp)
            shown = i
        }
    }
}
