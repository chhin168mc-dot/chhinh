@echo off
REM Build everything on Windows. Needs: MinGW gcc/g++ (or MSYS2), JDK 17+, .NET 8 SDK, Node 18+, Python 3.10+
cd /d "%~dp0"
mkdir build\native build\java\classes build\core 2>nul

echo [C]    native SHA-1 library
gcc -O2 -shared -o build\native\nokorhash.dll native-c\nokorhash.c || exit /b 1
echo [C++]  system info probe
g++ -O2 -std=c++17 -o build\native\nokor_sysinfo.exe native-cpp\sysinfo.cpp || exit /b 1
echo [Java] NokorBoot wrapper
javac -d build\java\classes java\nokor\NokorBoot.java || exit /b 1
jar cf build\java\nokor-boot.jar -C build\java\classes . || exit /b 1
echo [C#]   core service
dotnet publish core-csharp\NokorLauncher.Core -c Release -o build\core || exit /b 1
copy /y build\native\nokorhash.dll build\core\ >nul
echo [Node] update server deps
pushd server-node && call npm install --omit=dev && popd
echo [Py]   UI deps
python -m pip install -r ui-python\requirements.txt

echo.
echo Done.  Update server:  node server-node\server.js
echo        Launcher UI:    python ui-python\main.py
