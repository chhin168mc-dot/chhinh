package com.example.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import java.util.Random
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * ផ្ទៃខាងក្រោយ "aurora" ត្រជាក់ភ្នែក៖ gradient ខៀវ-បៃតងទឹកសមុទ្រ
 * + ពន្លឺ (orb) រសាត់យឺតៗ + ភាគល្អិតភ្លឺរលោង + vignette ងងឹតបន្តិចនៅគែម។
 * គូរដោយ Canvas ទាំងអស់ — មិនប្រើរូបភាព ដូច្នេះស្រាល និងរលូន។
 */
class AuroraBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private class Orb(
        val cx: Float, val cy: Float,
        val ax: Float, val ay: Float,
        val speed: Float, val phase: Float,
        val radiusFactor: Float, val color: Int
    )

    private val orbs = listOf(
        Orb(0.12f, 0.20f, 0.10f, 0.14f, 0.11f, 0.0f, 0.62f, Color.parseColor("#4DD0E1")),
        Orb(0.88f, 0.22f, 0.08f, 0.16f, 0.09f, 2.0f, 0.55f, Color.parseColor("#5B8DEF")),
        Orb(0.55f, 0.98f, 0.16f, 0.08f, 0.13f, 4.0f, 0.65f, Color.parseColor("#26C6A0")),
        Orb(0.40f, 0.45f, 0.12f, 0.10f, 0.07f, 1.0f, 0.45f, Color.parseColor("#7C6CF0"))
    )

    private val count = 46
    private val rnd = Random(42)
    private val px = FloatArray(count) { rnd.nextFloat() }
    private val py = FloatArray(count) { rnd.nextFloat() }
    private val ps = FloatArray(count) { 0.012f + rnd.nextFloat() * 0.025f }
    private val pr = FloatArray(count) { 0.8f + rnd.nextFloat() * 1.8f }
    private val pph = FloatArray(count) { rnd.nextFloat() * 6.28f }

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val vignettePaint = Paint()

    private var animated = true

    fun setAnimated(on: Boolean) {
        animated = on
        invalidate()
    }

    private var orbShaders: List<RadialGradient> = emptyList()
    private val startTime = SystemClock.uptimeMillis()
    private val density = resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        val wf = w.toFloat()
        val hf = h.toFloat()

        basePaint.shader = LinearGradient(
            0f, 0f, wf, hf,
            intArrayOf(Color.parseColor("#04141F"), Color.parseColor("#0A2A3A"), Color.parseColor("#0B3A45")),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )

        val big = max(wf, hf)
        orbShaders = orbs.map { o ->
            val r = big * o.radiusFactor * 0.8f
            val c = o.color
            RadialGradient(
                0f, 0f, r,
                intArrayOf(
                    Color.argb(105, Color.red(c), Color.green(c), Color.blue(c)),
                    Color.argb(0, Color.red(c), Color.green(c), Color.blue(c))
                ),
                null,
                Shader.TileMode.CLAMP
            )
        }

        vignettePaint.shader = RadialGradient(
            wf / 2f, hf / 2f, big * 0.78f,
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(150, 2, 10, 18)),
            floatArrayOf(0.55f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f || orbShaders.isEmpty()) return

        val t = (SystemClock.uptimeMillis() - startTime) / 1000f

        canvas.drawRect(0f, 0f, w, h, basePaint)

        // orbs
        for (i in orbs.indices) {
            val o = orbs[i]
            val a = t * o.speed * 2f + o.phase
            val x = (o.cx + o.ax * sin(a)) * w
            val y = (o.cy + o.ay * cos(a * 0.8f)) * h
            val r = max(w, h) * o.radiusFactor * 0.8f
            orbPaint.shader = orbShaders[i]
            canvas.save()
            canvas.translate(x, y)
            canvas.drawCircle(0f, 0f, r, orbPaint)
            canvas.restore()
        }

        // particles
        for (i in 0 until count) {
            var y = (py[i] - t * ps[i]) % 1f
            if (y < 0f) y += 1f
            val x = px[i] + sin(t * 0.5f + pph[i]) * 0.01f
            val tw = (sin(t * 1.4f + pph[i]) + 1f) / 2f
            dotPaint.alpha = (255 * (0.18f + 0.40f * tw)).toInt()
            canvas.drawCircle(x * w, y * h, pr[i] * density, dotPaint)
        }

        canvas.drawRect(0f, 0f, w, h, vignettePaint)

        if (animated) postInvalidateOnAnimation()
    }
}
