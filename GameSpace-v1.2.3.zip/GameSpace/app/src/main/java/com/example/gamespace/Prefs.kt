package com.example.gamespace

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val SOUND = "sound_on"
    const val HAPTIC = "haptic_on"
    const val ANIM_BG = "anim_bg"
    const val AUTO_UPDATE = "auto_update"
    const val OVERLAY = "overlay_on"
    const val ASKED_OVERLAY = "asked_overlay"
    const val WINDOW_MODE = "window_mode" // 0 = បង្អួចអណ្ដែត, 1 = អេក្រង់បំបែក
    private const val ADDED_APPS = "added_apps"

    /** បញ្ជី app ដែលអ្នកប្រើបានបន្ថែម (ប្រើក្នុងផ្ទាំង overlay សម្រាប់បើកជាអេក្រង់បំបែក) */
    fun addedApps(ctx: Context): List<String> =
        of(ctx).getString(ADDED_APPS, "").orEmpty().split(",").filter { it.isNotBlank() }

    fun addApp(ctx: Context, pkg: String) {
        val list = addedApps(ctx)
        if (pkg in list) return
        of(ctx).edit().putString(ADDED_APPS, (list + pkg).joinToString(",")).apply()
    }

    fun removeApp(ctx: Context, pkg: String) {
        of(ctx).edit().putString(ADDED_APPS, addedApps(ctx).filter { it != pkg }.joinToString(",")).apply()
    }

    fun of(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("game_launcher_prefs", Context.MODE_PRIVATE)
}
