using System.Text;
using System.Text.Json.Nodes;

namespace NokorLauncher.Core;

/// <summary>Microsoft device-code login -> Xbox Live -> XSTS -> Minecraft services.</summary>
public static class MicrosoftAuth
{
    const string Tenant = "https://login.microsoftonline.com/consumers/oauth2/v2.0";
    const string Scope = "XboxLive.signin offline_access";
    static readonly HttpClient H = Installer.Http;

    static async Task<(bool ok, JsonNode body)> Form(string url, Dictionary<string, string> f)
    {
        using var r = await H.PostAsync(url, new FormUrlEncodedContent(f));
        return (r.IsSuccessStatusCode, JsonNode.Parse(await r.Content.ReadAsStringAsync())!);
    }

    static async Task<JsonNode> Json(string url, JsonNode body)
    {
        using var req = new HttpRequestMessage(HttpMethod.Post, url)
        { Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json") };
        req.Headers.Accept.ParseAdd("application/json");
        using var r = await H.SendAsync(req);
        var t = await r.Content.ReadAsStringAsync();
        if (!r.IsSuccessStatusCode) throw new Exception(Explain(t, (int)r.StatusCode));
        return JsonNode.Parse(t)!;
    }

    static string Explain(string body, int status)
    {
        if (body.Contains("2148916233")) return "This Microsoft account has no Xbox profile. Create one at xbox.com first.";
        if (body.Contains("2148916238")) return "Child account: it must be added to a Microsoft Family before it can sign in.";
        if (body.Contains("2148916235")) return "Xbox Live is not available in your country/region.";
        return $"Login failed (HTTP {status})";
    }

    public static async Task<JsonObject> LoginAsync(string clientId, Action<string, string> onCode)
    {
        var (ok, dc) = await Form($"{Tenant}/devicecode", new() { ["client_id"] = clientId, ["scope"] = Scope });
        if (!ok) throw new Exception("Device code request failed: " + (string?)dc["error_description"]);
        onCode((string)dc["user_code"]!, (string)dc["verification_uri"]!);

        int interval = (int?)dc["interval"] ?? 5;
        var deadline = DateTime.UtcNow.AddSeconds((int?)dc["expires_in"] ?? 900);
        while (DateTime.UtcNow < deadline)
        {
            await Task.Delay(interval * 1000);
            var (done, tok) = await Form($"{Tenant}/token", new()
            {
                ["grant_type"] = "urn:ietf:params:oauth:grant-type:device_code",
                ["client_id"] = clientId,
                ["device_code"] = (string)dc["device_code"]!,
            });
            if (done) return await FinishAsync((string)tok["access_token"]!, (string)tok["refresh_token"]!);
            var err = (string?)tok["error"];
            if (err == "authorization_pending") continue;
            if (err == "slow_down") { interval += 5; continue; }
            throw new Exception("Login cancelled or expired: " + err);
        }
        throw new Exception("Login timed out");
    }

    public static async Task<JsonObject> RefreshAsync(string clientId, string refreshToken)
    {
        var (ok, tok) = await Form($"{Tenant}/token", new()
        {
            ["grant_type"] = "refresh_token",
            ["client_id"] = clientId,
            ["refresh_token"] = refreshToken,
            ["scope"] = Scope,
        });
        if (!ok) throw new Exception("Session expired, please sign in again.");
        return await FinishAsync((string)tok["access_token"]!, (string?)tok["refresh_token"] ?? refreshToken);
    }

    static async Task<JsonObject> FinishAsync(string msAccess, string msRefresh)
    {
        var xbl = await Json("https://user.auth.xboxlive.com/user/authenticate", new JsonObject
        {
            ["Properties"] = new JsonObject { ["AuthMethod"] = "RPS", ["SiteName"] = "user.auth.xboxlive.com", ["RpsTicket"] = "d=" + msAccess },
            ["RelyingParty"] = "http://auth.xboxlive.com",
            ["TokenType"] = "JWT",
        });
        var uhs = (string)xbl["DisplayClaims"]!["xui"]![0]!["uhs"]!;

        var xsts = await Json("https://xsts.auth.xboxlive.com/xsts/authorize", new JsonObject
        {
            ["Properties"] = new JsonObject { ["SandboxId"] = "RETAIL", ["UserTokens"] = new JsonArray((string)xbl["Token"]!) },
            ["RelyingParty"] = "rp://api.minecraftservices.com/",
            ["TokenType"] = "JWT",
        });

        var mc = await Json("https://api.minecraftservices.com/authentication/login_with_xbox", new JsonObject
        { ["identityToken"] = $"XBL3.0 x={uhs};{(string)xsts["Token"]!}" });
        var mcToken = (string)mc["access_token"]!;

        using var req = new HttpRequestMessage(HttpMethod.Get, "https://api.minecraftservices.com/minecraft/profile");
        req.Headers.Authorization = new("Bearer", mcToken);
        using var resp = await H.SendAsync(req);
        if (resp.StatusCode == System.Net.HttpStatusCode.NotFound)
            throw new Exception("This account does not own Minecraft: Java Edition.");
        resp.EnsureSuccessStatusCode();
        var prof = JsonNode.Parse(await resp.Content.ReadAsStringAsync())!;

        return new JsonObject
        {
            ["type"] = "msa",
            ["name"] = (string)prof["name"]!,
            ["uuid"] = (string)prof["id"]!,
            ["accessToken"] = mcToken,
            ["refreshToken"] = msRefresh,
        };
    }
}
