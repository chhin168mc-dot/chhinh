cmake_minimum_required(VERSION 3.22.1)
project(gamezombie)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(gamezombie SHARED
    main.cpp
    game.cpp
    renderer.cpp
)

find_library(log-lib log)
find_library(android-lib android)
find_library(EGL-lib EGL)
find_library(GLESv2-lib GLESv2)

target_link_libraries(gamezombie
    ${log-lib}
    ${android-lib}
    ${EGL-lib}
    ${GLESv2-lib}
    android
)

# Include native_app_glue
set(NATIVE_APP_GLUE_DIR ${ANDROID_NDK}/sources/android/native_app_glue)
add_library(native_app_glue STATIC ${NATIVE_APP_GLUE_DIR}/android_native_app_glue.c)
target_include_directories(gamezombie PRIVATE ${NATIVE_APP_GLUE_DIR})
target_link_libraries(gamezombie native_app_glue)

# Export ANativeActivity_onCreate
set_target_properties(gamezombie PROPERTIES
    LINK_FLAGS "-u ANativeActivity_onCreate"
)
