/* NokorLauncher - native SHA-1 file hashing (C).
 * Exported: int nokor_sha1_file(const char *utf8_path, char out_hex[41])
 * Returns 0 on success, -1 on error. Loaded by the C# core through P/Invoke. */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#define NK_EXPORT __declspec(dllexport)
#else
#define NK_EXPORT __attribute__((visibility("default")))
#endif

typedef struct { uint32_t h[5]; uint64_t len; uint8_t buf[64]; size_t n; } sha1_ctx;

static uint32_t rol(uint32_t v, int b) { return (v << b) | (v >> (32 - b)); }

static void sha1_block(sha1_ctx *c, const uint8_t *p) {
    uint32_t w[80], a = c->h[0], b = c->h[1], cc = c->h[2], d = c->h[3], e = c->h[4];
    for (int i = 0; i < 16; i++)
        w[i] = ((uint32_t)p[4*i] << 24) | ((uint32_t)p[4*i+1] << 16) | ((uint32_t)p[4*i+2] << 8) | p[4*i+3];
    for (int i = 16; i < 80; i++) w[i] = rol(w[i-3] ^ w[i-8] ^ w[i-14] ^ w[i-16], 1);
    for (int i = 0; i < 80; i++) {
        uint32_t f, k;
        if (i < 20)      { f = (b & cc) | (~b & d);            k = 0x5A827999; }
        else if (i < 40) { f = b ^ cc ^ d;                     k = 0x6ED9EBA1; }
        else if (i < 60) { f = (b & cc) | (b & d) | (cc & d);  k = 0x8F1BBCDC; }
        else             { f = b ^ cc ^ d;                     k = 0xCA62C1D6; }
        uint32_t t = rol(a, 5) + f + e + k + w[i];
        e = d; d = cc; cc = rol(b, 30); b = a; a = t;
    }
    c->h[0] += a; c->h[1] += b; c->h[2] += cc; c->h[3] += d; c->h[4] += e;
}

static void sha1_init(sha1_ctx *c) {
    c->h[0] = 0x67452301; c->h[1] = 0xEFCDAB89; c->h[2] = 0x98BADCFE;
    c->h[3] = 0x10325476; c->h[4] = 0xC3D2E1F0; c->len = 0; c->n = 0;
}

static void sha1_update(sha1_ctx *c, const uint8_t *d, size_t len) {
    c->len += len;
    while (len) {
        size_t take = 64 - c->n; if (take > len) take = len;
        memcpy(c->buf + c->n, d, take); c->n += take; d += take; len -= take;
        if (c->n == 64) { sha1_block(c, c->buf); c->n = 0; }
    }
}

static void sha1_final(sha1_ctx *c, uint8_t out[20]) {
    uint64_t bits = c->len * 8;
    uint8_t pad = 0x80; sha1_update(c, &pad, 1);
    uint8_t z = 0; while (c->n != 56) sha1_update(c, &z, 1);
    uint8_t lb[8]; for (int i = 0; i < 8; i++) lb[i] = (uint8_t)(bits >> (56 - 8 * i));
    sha1_update(c, lb, 8);
    for (int i = 0; i < 5; i++) {
        out[4*i] = c->h[i] >> 24; out[4*i+1] = c->h[i] >> 16; out[4*i+2] = c->h[i] >> 8; out[4*i+3] = c->h[i];
    }
}

NK_EXPORT int nokor_sha1_file(const char *path, char *out_hex) {
    if (!path || !out_hex) return -1;
#ifdef _WIN32
    wchar_t wpath[4096];
    if (!MultiByteToWideChar(CP_UTF8, 0, path, -1, wpath, 4096)) return -1;
    FILE *f = _wfopen(wpath, L"rb");
#else
    FILE *f = fopen(path, "rb");
#endif
    if (!f) return -1;
    sha1_ctx c; sha1_init(&c);
    enum { BUF = 1 << 16 };
    uint8_t chunk[1 << 16]; size_t n;
    while ((n = fread(chunk, 1, BUF, f)) > 0) sha1_update(&c, chunk, n);
    int err = ferror(f); fclose(f);
    if (err) return -1;
    uint8_t d[20]; sha1_final(&c, d);
    static const char *hx = "0123456789abcdef";
    for (int i = 0; i < 20; i++) { out_hex[2*i] = hx[d[i] >> 4]; out_hex[2*i+1] = hx[d[i] & 15]; }
    out_hex[40] = 0;
    return 0;
}
