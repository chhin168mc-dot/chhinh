package com.example.gamespace

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * ប្រើតែមួយមុខងារ: បញ្ជាឲ្យប្រព័ន្ធបំបែកអេក្រង់ (split-screen) ដោយមិនអានមាតិកាអេក្រង់ទេ។
 */
class SplitAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    fun toggleSplit(): Boolean = performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)

    companion object {
        @Volatile
        var instance: SplitAccessibilityService? = null
    }
}
