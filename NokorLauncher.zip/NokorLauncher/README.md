# NokorLauncher — `com.nokorlauncher.mc` — v20.26.1.0

Minecraft: Java Edition launcher. Each language has a real job:

| Language | Folder | Role |
|---|---|---|
| **Python** (PySide6) | `ui-python/` | UI + all animations (open, background, click ripple, download shimmer, button hover, page fades), sound, Modrinth mods/resource packs, update check |
| **C#** (.NET 8) | `core-csharp/` | Core service: Mojang version list, download/verify, `inheritsFrom` merging (OptiFine/Fabric), game launch, offline UUID, Microsoft/Xbox login. Talks to the UI with JSON lines |
| **C** | `native-c/` | `nokorhash` — SHA-1 file hashing, called from C# via P/Invoke (managed fallback) |
| **C++** | `native-cpp/` | `nokor_sysinfo` — RAM / CPU / Java detection → recommended memory in Settings |
| **Java** | `java/` | `NokorBoot` — tiny wrapper that starts the real Minecraft main class (also runs OptiFine installer) |
| **Node.js** | `server-node/` | Update backend: `GET /api/update`, `POST /api/admin/release` |

```
Python UI ──JSON lines──▶ C# core ──P/Invoke──▶ C (sha1)
   │                          └─ spawns ─▶ java ─▶ NokorBoot ─▶ Minecraft
   ├─▶ C++ sysinfo
   └─HTTP─▶ Node update server      └─HTTP─▶ Modrinth API
```

## Build & run
```
./build_all.sh          # Windows: build_all.bat
node server-node/server.js        # optional, update backend (NOKOR_ADMIN_KEY=... to enable admin API)
python3 ui-python/main.py
```
Put `open.ogg`, `button.ogg`, `background.ogg` in `assets/sounds/`.

## GitHub Actions (`.github/workflows/build.yml`)
Runs on push / PR / manual dispatch and builds **Windows, Linux and macOS** packages (not APK - see below):
`server` job (Node.js: install, syntax check, smoke test) and `launcher` job per OS (C, C++ tests, Java jar,
self-contained C# core, PyInstaller UI) -> artifacts `NokorLauncher-<os>`.
Push a tag like `v20.26.1.0` to also create a GitHub Release with all packages attached.

**No APK:** this launcher is a desktop app and Minecraft: Java Edition cannot run as a plain Android app.

## Features
- **Download Version Minecraft** — releases, snapshots, **OptiFine 1.21.11** style entries, installed list
- **Play Game Minecraft** — auto-downloads if missing, refreshes Premium session, launches, live game log
- **Download Mods and Resources pack** — Modrinth search/download (mods, resource packs, shaders)
- **Settings Launcher** — RAM, Java, NokorBoot, sound, Azure client id, update server
- **Offline account and Premium account**

## Important notes
- **Premium login** needs your own Azure app: register a public client at portal.azure.com with
  "Allow public client flows" enabled, then paste its Application (client) ID in Settings.
  Mojang may require the app to be approved for the Minecraft API.
- **OptiFine** has no public download API. The launcher installs vanilla, opens optifine.net, then runs the official
  installer; point it to the game folder shown in the dialog.
- Account tokens are stored in `settings.json` (chmod 600 on Unix). Use an OS keyring for production.
- Not yet supported: Minecraft ≤1.7 virtual/legacy assets, Forge/NeoForge installers, mod dependency resolution.
- Verified here: C and C++ compile and pass tests, Node syntax. C#, Java and the PySide6 UI were written without
  a compiler/runtime available — expect to fix small compile errors on first build.
- Not affiliated with Mojang or Microsoft. A purchased Minecraft: Java Edition is required for Premium accounts.
