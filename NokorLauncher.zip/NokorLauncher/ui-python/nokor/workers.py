from PySide6.QtCore import QThread, Signal


class Worker(QThread):
    """Run fn(progress_cb) off the UI thread."""
    progress = Signal(int, str)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn(lambda pct, text="": self.progress.emit(int(pct), text)))
        except Exception as e:  # noqa: BLE001
            self.failed.emit(str(e))
