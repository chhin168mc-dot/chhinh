import json
import os
import subprocess

from .config import SYSINFO


def sysinfo() -> dict:
    """Uses the C++ probe (nokor_sysinfo); falls back to safe defaults."""
    try:
        out = subprocess.run([str(SYSINFO)], capture_output=True, text=True, timeout=5).stdout
        return json.loads(out)
    except Exception:  # noqa: BLE001
        return {"total_ram_mb": 8192, "cores": os.cpu_count() or 4, "recommended_ram_mb": 4096, "java": []}
