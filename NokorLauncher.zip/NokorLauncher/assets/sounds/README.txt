Put your sound files here (the launcher ignores missing files):
  open.ogg        - played once when the app opens
  button.ogg      - played on every button click
  background.ogg  - looped background music
