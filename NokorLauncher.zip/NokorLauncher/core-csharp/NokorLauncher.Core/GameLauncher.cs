using System.Diagnostics;
using System.IO.Compression;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace NokorLauncher.Core;

public static class GameLauncher
{
    public static async Task<int> LaunchAsync(string root, string id, Dictionary<string, string> o)
    {
        var v = VersionData.Load(root, id);
        var jarId = (string)v["_jar"]!;
        var natives = Path.Combine(root, "versions", id, "natives");
        Directory.CreateDirectory(natives);

        var cp = new List<string>();
        foreach (var l in VersionData.Libraries(v))
        {
            var p = Path.Combine(root, "libraries", l.Path);
            if (!File.Exists(p)) continue;
            if (l.Extract) ExtractNatives(p, natives);
            else if (!cp.Contains(p)) cp.Add(p);
        }
        cp.Add(Path.Combine(root, "versions", jarId, jarId + ".jar"));

        var boot = o.GetValueOrDefault("boot");
        if (boot != null && File.Exists(boot)) cp.Add(boot); else boot = null;

        var vars = new Dictionary<string, string>
        {
            ["auth_player_name"] = o.Req("name"),
            ["auth_uuid"] = o.Req("uuid"),
            ["auth_access_token"] = Environment.GetEnvironmentVariable("NOKOR_TOKEN") ?? "0",
            ["auth_xuid"] = "0",
            ["clientid"] = "nokorlauncher",
            ["user_type"] = o.GetValueOrDefault("user-type", "legacy"),
            ["user_properties"] = "{}",
            ["version_name"] = id,
            ["version_type"] = (string?)v["type"] ?? "release",
            ["game_directory"] = root,
            ["assets_root"] = Path.Combine(root, "assets"),
            ["game_assets"] = Path.Combine(root, "assets"),
            ["assets_index_name"] = (string?)v["assetIndex"]?["id"] ?? (string?)v["assets"] ?? "legacy",
            ["natives_directory"] = natives,
            ["library_directory"] = Path.Combine(root, "libraries"),
            ["classpath"] = string.Join(Path.PathSeparator, cp),
            ["classpath_separator"] = Path.PathSeparator.ToString(),
            ["launcher_name"] = "NokorLauncher",
            ["launcher_version"] = "20.26.1.0",
        };

        var jvm = new List<string>();
        var game = new List<string>();
        if (v["arguments"] is JsonObject a)
        {
            Collect(a["jvm"], jvm, vars);
            Collect(a["game"], game, vars);
        }
        else
        {
            game.AddRange(((string?)v["minecraftArguments"] ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(x => Subst(x, vars)));
        }
        if (!jvm.Any(x => x.StartsWith("-Djava.library.path"))) jvm.Add("-Djava.library.path=" + natives);
        if (!jvm.Contains("-cp") && !jvm.Contains("-classpath")) { jvm.Add("-cp"); jvm.Add(vars["classpath"]); }

        var mainClass = (string)v["mainClass"]!;
        if (boot != null) { game.Insert(0, mainClass); mainClass = "nokor.NokorBoot"; }

        var ram = int.TryParse(o.GetValueOrDefault("ram"), out var r) ? r : 4096;
        var argv = new List<string> { $"-Xmx{ram}M", "-Xms256M" };
        argv.AddRange(jvm);
        argv.Add(mainClass);
        argv.AddRange(game);

        var psi = new ProcessStartInfo(o.GetValueOrDefault("java", "java"))
        {
            WorkingDirectory = root,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
        };
        foreach (var x in argv) psi.ArgumentList.Add(x);

        using var p = new Process { StartInfo = psi };
        p.OutputDataReceived += (_, e) => { if (e.Data != null) Out.Emit(new { type = "log", line = e.Data }); };
        p.ErrorDataReceived += (_, e) => { if (e.Data != null) Out.Emit(new { type = "log", line = e.Data }); };
        p.Start();
        Out.Emit(new { type = "started", pid = p.Id });
        p.BeginOutputReadLine();
        p.BeginErrorReadLine();
        await p.WaitForExitAsync();
        Out.Emit(new { type = "exit", code = p.ExitCode });
        return p.ExitCode;
    }

    static string Subst(string s, Dictionary<string, string> vars) =>
        Regex.Replace(s, @"\$\{(\w+)\}", m => vars.TryGetValue(m.Groups[1].Value, out var x) ? x : m.Value);

    static void Collect(JsonNode? arr, List<string> into, Dictionary<string, string> vars)
    {
        if (arr is not JsonArray ja) return;
        foreach (var item in ja)
        {
            if (item is JsonValue) { into.Add(Subst((string)item!, vars)); continue; }
            if (item is JsonObject io && Rules.Allow(io["rules"]))
            {
                var val = io["value"];
                if (val is JsonArray va) foreach (var x in va) into.Add(Subst((string)x!, vars));
                else if (val != null) into.Add(Subst((string)val, vars));
            }
        }
    }

    static void ExtractNatives(string zip, string dir)
    {
        var full = Path.GetFullPath(dir) + Path.DirectorySeparatorChar;
        using var z = ZipFile.OpenRead(zip);
        foreach (var e in z.Entries)
        {
            if (e.FullName.EndsWith('/') || e.FullName.StartsWith("META-INF")) continue;
            var dest = Path.GetFullPath(Path.Combine(dir, e.FullName));
            if (!dest.StartsWith(full)) continue; // zip-slip guard
            Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
            e.ExtractToFile(dest, true);
        }
    }
}
