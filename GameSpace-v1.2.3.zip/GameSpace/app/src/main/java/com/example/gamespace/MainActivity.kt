package com.example.gamespace

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Process
import android.provider.Settings
import android.view.ViewOutlineProvider
import android.graphics.Outline
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.widget.SwitchCompat
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var content: View
    private lateinit var rail: View
    private lateinit var panel: View
    private lateinit var topBar: View
    private lateinit var panelInfo: View
    private lateinit var splash: View
    private lateinit var rv: RecyclerView
    private lateinit var adapter: GameAdapter
    private lateinit var tvCounter: TextView
    private lateinit var tvGameName: TextView
    private lateinit var tvGameType: TextView
    private lateinit var tvGameInfo: TextView
    private lateinit var tvPanelLetter: TextView
    private lateinit var ivPanelIcon: ImageView
    private lateinit var btnPlay: View
    private lateinit var playGlow: View
    private lateinit var ivIntro: ImageView
    private lateinit var navs: List<ImageView>

    private lateinit var overlay: View
    private lateinit var overlayCard: View
    private lateinit var overlayTitle: TextView
    private lateinit var overlayBody: LinearLayout
    private lateinit var aurora: AuroraBackgroundView
    private lateinit var prefs: SharedPreferences
    private var overlayMode = 0   // 0 = បិទ, 1 = ហាង, 2 = ការកំណត់
    private var currentTab = 0    // 0 = ទំព័រដើម, 1 = ហ្គេម
    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            closeOverlay()
        }
    }

    private val snapHelper = LinearSnapHelper()
    private val updater by lazy { UpdateManager(this) }

    private var allItems: List<GameItem> = emptyList()
    private var gamesOnly = false
    private var selectedPos = -1

    private var loadDone = false
    private var animDone = false
    private var revealed = false

    private var intro: IntroPlayer? = null
    private var pendingLaunch: String? = null
    private var glowAnim: ObjectAnimator? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs.of(this)
        setupWindow()
        bindViews()
        setupOverlay()
        setupNav()
        setupList()
        setupPlayButton()
        setupVersionLabel()
        startSplash()
        loadAppsAsync()
    }

    // ---------------------------------------------------------------- window

    private fun setupWindow() {
        // ពេញអេក្រង់ (immersive) ដូចហ្គេម
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    // ----------------------------------------------------------------- views

    private fun bindViews() {
        content = findViewById(R.id.content)
        rail = findViewById(R.id.rail)
        panel = findViewById(R.id.panel)
        topBar = findViewById(R.id.topBar)
        panelInfo = findViewById(R.id.panelInfo)
        splash = findViewById(R.id.splash)
        rv = findViewById(R.id.rvGames)
        tvCounter = findViewById(R.id.tvCounter)
        tvGameName = findViewById(R.id.tvGameName)
        tvGameType = findViewById(R.id.tvGameType)
        tvGameInfo = findViewById(R.id.tvGameInfo)
        tvPanelLetter = findViewById(R.id.tvPanelLetter)
        ivPanelIcon = findViewById(R.id.ivPanelIcon)
        btnPlay = findViewById(R.id.btnPlay)
        playGlow = findViewById(R.id.playGlow)
        ivIntro = findViewById(R.id.ivIntro)
        overlay = findViewById(R.id.overlay)
        overlayCard = findViewById(R.id.overlayCard)
        overlayTitle = findViewById(R.id.overlayTitle)
        overlayBody = findViewById(R.id.overlayBody)
        aurora = findViewById(R.id.aurora)
        navs = listOf(
            findViewById(R.id.navHome),
            findViewById(R.id.navGames),
            findViewById(R.id.navStore),
            findViewById(R.id.navSettings)
        )

        // ទុកគែមអេក្រង់ (notch / rounded corners) ឲ្យ lobby មិនត្រូវកាត់
        val baseLeft = content.paddingLeft
        val baseTop = content.paddingTop
        val baseRight = content.paddingRight
        val baseBottom = content.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(content) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(baseLeft + i.left, baseTop + i.top, baseRight + i.right, baseBottom + i.bottom)
            insets
        }

        // លាក់ lobby រហូតដល់ splash ចប់
        listOf(rail, panel, topBar, rv).forEach { it.alpha = 0f }
    }

    private fun setupNav() {
        setNavSelected(0)
        navs[0].setOnClickListener {
            closeOverlay(animate = false)
            currentTab = 0
            setNavSelected(0)
            gamesOnly = false
            applyFilter()
        }
        navs[1].setOnClickListener {
            closeOverlay(animate = false)
            currentTab = 1
            setNavSelected(1)
            gamesOnly = true
            applyFilter()
        }
        navs[2].setOnClickListener { openOverlay(1) }
        navs[3].setOnClickListener { openOverlay(2) }
    }

    private fun setNavSelected(index: Int) {
        val on = Color.parseColor("#FF7CF5D0")
        val off = Color.parseColor("#99A9D6E3")
        navs.forEachIndexed { i, v ->
            v.isSelected = i == index
            v.setColorFilter(if (i == index) on else off)
        }
    }

    private fun setupVersionLabel() {
        val tv = findViewById<TextView>(R.id.tvHubSubtitle)
        tv.text = getString(R.string.hub_subtitle) + " · v" + updater.currentVersion()
        // ចុចលើ version ដើម្បីពិនិត្យ update ដោយដៃ
        tv.setOnClickListener { updater.check(true) }
    }

    // ------------------------------------------------------------- carousel

    private fun setupList() {
        adapter = GameAdapter { pos -> onCardClicked(pos) }
        val lm = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rv.layoutManager = lm
        rv.adapter = adapter
        rv.itemAnimator = null
        snapHelper.attachToRecyclerView(rv)

        // ធ្វើឲ្យកាតទីមួយ/ចុងក្រោយនៅកណ្ដាលអេក្រង់បាន
        rv.doOnLayout {
            val itemW = dp(170 + 20)
            val pad = ((rv.width - itemW) / 2).coerceAtLeast(0)
            rv.setPadding(pad, 0, pad, 0)
        }

        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                updateScale()
                updateSelection(false)
            }
        })
        rv.addOnChildAttachStateChangeListener(object : RecyclerView.OnChildAttachStateChangeListener {
            override fun onChildViewAttachedToWindow(view: View) {
                rv.post { updateScale() }
            }

            override fun onChildViewDetachedFromWindow(view: View) {}
        })
    }

    /** កាតនៅកណ្ដាល = ធំ + ភ្លឺ, កាតនៅគែម = តូច + ស្រអាប់ */
    private fun updateScale() {
        val half = rv.width / 2f
        if (half <= 0f) return
        val center = half
        for (i in 0 until rv.childCount) {
            val c = rv.getChildAt(i)
            val cc = (c.left + c.right) / 2f
            val d = min(1f, abs(cc - center) / half)
            val s = 1f - 0.20f * d
            c.scaleX = s
            c.scaleY = s
            c.alpha = 1f - 0.50f * d
        }
    }

    private fun updateSelection(force: Boolean) {
        val lm = rv.layoutManager as? LinearLayoutManager ?: return
        if (adapter.itemCount == 0) return
        val snapView = snapHelper.findSnapView(lm)
        var pos = if (snapView != null) rv.getChildAdapterPosition(snapView) else RecyclerView.NO_POSITION
        if (pos == RecyclerView.NO_POSITION) {
            if (!force) return
            pos = 0
        }
        if (pos != selectedPos || force) {
            val first = selectedPos == -1
            selectedPos = pos
            bindPanel(adapter.getItem(pos), pos)
            if (!first && !force && prefs.getBoolean(Prefs.HAPTIC, true)) rv.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun bindPanel(item: GameItem?, pos: Int) {
        if (item == null) return
        tvGameName.text = item.label
        tvGameType.setText(
            when (item.kind) {
                ItemKind.GAME -> R.string.type_game
                ItemKind.APP -> R.string.type_app
                ItemKind.DEMO -> R.string.type_demo
            }
        )
        tvGameInfo.text = item.packageName ?: ""
        tvCounter.text = "${pos + 1} / ${adapter.itemCount}"

        if (item.icon != null) {
            ivPanelIcon.visibility = View.VISIBLE
            ivPanelIcon.setImageDrawable(item.icon)
            tvPanelLetter.visibility = View.GONE
        } else {
            ivPanelIcon.visibility = View.GONE
            tvPanelLetter.visibility = View.VISIBLE
            tvPanelLetter.text = item.label.take(1).uppercase()
        }

        panelInfo.alpha = 0.25f
        panelInfo.animate().alpha(1f).setDuration(220).start()
    }

    private fun onCardClicked(pos: Int) {
        if (pos == selectedPos) playSelected() else centerOn(pos)
    }

    private fun centerOn(pos: Int) {
        val lm = rv.layoutManager as? LinearLayoutManager ?: return
        val child = lm.findViewByPosition(pos)
        if (child != null) {
            val dx = ((child.left + child.right) / 2f - rv.width / 2f).toInt()
            rv.smoothScrollBy(dx, 0)
        } else {
            rv.smoothScrollToPosition(pos)
        }
    }

    private fun applyFilter() {
        val base = if (gamesOnly) allItems.filter { it.kind == ItemKind.GAME } else allItems
        val shown = if (base.isEmpty()) demoItems() else base
        adapter.submit(shown)
        selectedPos = -1
        rv.scrollToPosition(0)
        rv.post {
            updateScale()
            updateSelection(true)
        }
    }

    // ----------------------------------------------------------- data (apps)

    private fun loadAppsAsync() {
        Thread {
            val items = try {
                queryLaunchables()
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                allItems = items
                loadDone = true
                tryReveal()
            }
        }.start()
    }

    private fun queryLaunchables(): List<GameItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val resolved: List<ResolveInfo> = pm.queryIntentActivities(intent, 0)
        return resolved
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri -> buildItem(pm, ri) }
            .sortedWith(
                compareBy<GameItem> { if (it.kind == ItemKind.GAME) 0 else 1 }
                    .thenBy { it.label.lowercase() }
            )
    }

    private fun buildItem(pm: PackageManager, ri: ResolveInfo): GameItem {
        val label = ri.loadLabel(pm).toString()
        val pkg = ri.activityInfo.packageName
        val (a, b) = GameItem.colorsFor(pkg)
        return GameItem(
            label = label,
            packageName = pkg,
            icon = ri.loadIcon(pm),
            kind = if (isGame(ri.activityInfo.applicationInfo)) ItemKind.GAME else ItemKind.APP,
            colorA = a,
            colorB = b
        )
    }

    @Suppress("DEPRECATION")
    private fun isGame(info: ApplicationInfo): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && info.category == ApplicationInfo.CATEGORY_GAME) return true
        return (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }

    private fun demoItems(): List<GameItem> {
        val names = listOf("Cyber Arena", "Dragon Realm", "Sky Racer", "Frost Legends", "Neon Strike")
        return names.map { n ->
            val (a, b) = GameItem.colorsFor(n)
            GameItem(n, null, null, ItemKind.DEMO, a, b)
        }
    }

    // ------------------------------------------------------------------ play

    private fun setupPlayButton() {
        btnPlay.setOnClickListener {
            btnPlay.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).withEndAction {
                btnPlay.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                playSelected()
            }.start()
        }

        // ពន្លឺ pulse ក្រោមប៊ូតុង
        glowAnim = ObjectAnimator.ofPropertyValuesHolder(
            playGlow,
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.25f, 0.95f),
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.07f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.18f)
        ).apply {
            duration = 1100
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun playSelected() {
        val item = adapter.getItem(selectedPos) ?: return
        val pkg = item.packageName
        if (pkg == null) {
            toast(R.string.toast_demo)
            return
        }
        launchPackage(pkg)
    }

    private fun launchPackage(pkg: String) {
        // ត្រូវការអនុញ្ញាត overlay ម្ដង — សួរតែលើកដំបូង
        val wantOverlay = prefs.getBoolean(Prefs.OVERLAY, true)
        if (wantOverlay && !OverlayService.canDraw(this) && !prefs.getBoolean(Prefs.ASKED_OVERLAY, false)) {
            prefs.edit().putBoolean(Prefs.ASKED_OVERLAY, true).apply()
            pendingLaunch = pkg   // លេងដោយស្វ័យប្រវត្តិ ពេលត្រឡប់មកវិញ
            toast(R.string.toast_need_overlay)
            openOverlayPermission()
            return
        }
        try {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                if (wantOverlay && OverlayService.canDraw(this)) {
                    val game = try {
                        isGame(packageManager.getApplicationInfo(pkg, 0))
                    } catch (e: Exception) {
                        false
                    }
                    OverlayService.start(this, pkg, game)
                }
            } else {
                toast(R.string.toast_open_failed)
            }
        } catch (e: Exception) {
            toast(R.string.toast_open_failed)
        }
    }

    private fun openOverlayPermission() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast(R.string.toast_open_failed)
        }
    }

    private fun openSettingsScreen(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast(R.string.toast_open_failed)
        }
    }

    private fun accessibilityOn(): Boolean = SplitAccessibilityService.instance != null

    // ------------------------------------------------- overlay: ហាង / ការកំណត់

    private fun setupOverlay() {
        findViewById<View>(R.id.overlayClose).setOnClickListener { closeOverlay() }
        overlay.setOnClickListener { closeOverlay() }
        onBackPressedDispatcher.addCallback(this, backCallback)
        aurora.setAnimated(prefs.getBoolean(Prefs.ANIM_BG, true))
    }

    private fun openOverlay(mode: Int) {
        overlayMode = mode
        backCallback.isEnabled = true
        setNavSelected(if (mode == 1) 2 else 3)
        overlayBody.removeAllViews()
        if (mode == 1) {
            overlayTitle.setText(R.string.store_title)
            buildStore()
        } else {
            overlayTitle.setText(R.string.settings_title)
            buildSettings()
        }
        overlay.visibility = View.VISIBLE
        overlay.alpha = 0f
        overlayCard.scaleX = 0.94f
        overlayCard.scaleY = 0.94f
        overlay.animate().alpha(1f).setDuration(200).start()
        overlayCard.animate().scaleX(1f).scaleY(1f).setDuration(220).start()
    }

    private fun closeOverlay(animate: Boolean = true) {
        if (overlayMode == 0) return
        overlayMode = 0
        backCallback.isEnabled = false
        setNavSelected(currentTab)
        if (animate) {
            overlay.animate().alpha(0f).setDuration(160).withEndAction {
                if (overlayMode == 0) overlay.visibility = View.GONE
            }.start()
        } else {
            overlay.animate().cancel()
            overlay.visibility = View.GONE
        }
    }

    private fun inflateRow(title: Int, desc: String): View {
        val row = LayoutInflater.from(this).inflate(R.layout.item_setting, overlayBody, false)
        row.findViewById<TextView>(R.id.tvTitle).setText(title)
        row.findViewById<TextView>(R.id.tvDesc).text = desc
        overlayBody.addView(row)
        return row
    }

    private fun addSwitch(title: Int, desc: Int, key: String, onChange: (Boolean) -> Unit = {}) {
        val row = inflateRow(title, getString(desc))
        val sw = row.findViewById<SwitchCompat>(R.id.sw)
        sw.isChecked = prefs.getBoolean(key, true)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            onChange(checked)
        }
        row.setOnClickListener { sw.toggle() }
    }

    private fun addAction(title: Int, desc: String, onClick: () -> Unit) {
        val row = inflateRow(title, desc)
        row.findViewById<View>(R.id.sw).visibility = View.GONE
        row.findViewById<View>(R.id.tvChevron).visibility = View.VISIBLE
        row.setOnClickListener { onClick() }
    }

    private fun buildSettings() {
        addSwitch(R.string.set_sound, R.string.set_sound_desc, Prefs.SOUND)
        addSwitch(R.string.set_haptic, R.string.set_haptic_desc, Prefs.HAPTIC)
        addSwitch(R.string.set_anim, R.string.set_anim_desc, Prefs.ANIM_BG) { aurora.setAnimated(it) }
        addSwitch(R.string.set_auto_update, R.string.set_auto_update_desc, Prefs.AUTO_UPDATE)
        addSwitch(R.string.set_overlay, R.string.set_overlay_desc, Prefs.OVERLAY)
        addAction(
            R.string.set_win_mode,
            getString(if (prefs.getInt(Prefs.WINDOW_MODE, 0) == 0) R.string.win_floating else R.string.win_split)
        ) {
            val next = if (prefs.getInt(Prefs.WINDOW_MODE, 0) == 0) 1 else 0
            prefs.edit().putInt(Prefs.WINDOW_MODE, next).apply()
            openOverlay(2)
        }
        addAction(
            R.string.set_perm_overlay,
            getString(if (OverlayService.canDraw(this)) R.string.perm_on else R.string.perm_off)
        ) { closeOverlay(); openOverlayPermission() }
        addAction(
            R.string.set_perm_usage,
            getString(if (OverlayService.hasUsageAccess(this)) R.string.perm_on else R.string.perm_off) +
                " · " + getString(R.string.set_perm_usage_desc)
        ) { closeOverlay(); openSettingsScreen(Settings.ACTION_USAGE_ACCESS_SETTINGS) }
        addAction(
            R.string.set_perm_acc,
            getString(if (accessibilityOn()) R.string.perm_on else R.string.perm_off) +
                " · " + getString(R.string.set_perm_acc_desc)
        ) { closeOverlay(); openSettingsScreen(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        addAction(R.string.set_check_update, "v" + updater.currentVersion()) {
            closeOverlay()
            updater.check(true)
        }
        val about = TextView(this).apply {
            text = getString(R.string.set_about, updater.currentVersion())
            setTextColor(Color.parseColor("#B3BFE3EC"))
            textSize = 11f
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        overlayBody.addView(about)
    }

    private fun isInstalled(pkg: String): Boolean =
        try {
            packageManager.getLaunchIntentForPackage(pkg) != null
        } catch (e: Exception) {
            false
        }

    private fun buildStore(games: List<StoreGame> = StoreCatalog.games, fetchRemote: Boolean = true) {
        if (fetchRemote) {
            val repo = getString(R.string.github_repo)
            GitHubBackend.fetchStore(repo) { remoteGames ->
                runOnUiThread {
                    if (!isFinishing && !isDestroyed && overlayMode == 1 && remoteGames != games) {
                        overlayBody.removeAllViews()
                        buildStore(remoteGames, fetchRemote = false)
                    }
                }
            }
        }
        addAction(R.string.store_search, getString(R.string.store_search_desc)) {
            openUrl("market://search?q=game&c=apps", "https://play.google.com/store/search?q=game&c=apps")
        }
        for (g in games) {
            val row = LayoutInflater.from(this).inflate(R.layout.item_store_game, overlayBody, false)
            val tile = row.findViewById<TextView>(R.id.tvTile)
            val tileIcon = row.findViewById<ImageView>(R.id.ivTileIcon)
            val (ca, cb) = GameItem.colorsFor(g.packageName)
            tile.text = g.name.take(1).uppercase()
            row.findViewById<View>(R.id.tile).background =
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ca, cb)).apply {
                    cornerRadius = dp(14).toFloat()
                }
            // មូល-ជ្រុង ដើម្បីឲ្យ logo ស្អាតដូចក្នុង Play Store
            tileIcon.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            tileIcon.clipToOutline = true
            // logo ពិត: icon ក្នុងទូរស័ព្ទ ឬទាញពី Google Play / iconUrl (បង្ហាញអក្សរក្នុងពេលរង់ចាំ)
            IconLoader.load(this, g.packageName, g.iconUrl) { d ->
                if (d != null && !isFinishing && !isDestroyed) {
                    tileIcon.setImageDrawable(d)
                    tileIcon.visibility = View.VISIBLE
                    tile.visibility = View.GONE
                }
            }
            row.findViewById<TextView>(R.id.tvName).text = g.name
            val installed = isInstalled(g.packageName)
            row.findViewById<TextView>(R.id.tvStatus).text =
                g.tag + " · " + getString(if (installed) R.string.store_installed else R.string.store_not_installed)
            row.findViewById<TextView>(R.id.tvAction).setText(if (installed) R.string.store_open else R.string.store_install)
            val click = View.OnClickListener {
                if (installed) {
                    launchPackage(g.packageName)
                } else {
                    openUrl(
                        "market://details?id=${g.packageName}",
                        "https://play.google.com/store/apps/details?id=${g.packageName}"
                    )
                }
            }
            row.setOnClickListener(click)
            row.findViewById<View>(R.id.tvAction).setOnClickListener(click)
            overlayBody.addView(row)
        }
    }

    private fun openUrl(primary: String, fallback: String) {
        try {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(primary)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: ActivityNotFoundException) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallback)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (e: Exception) {
            toast(R.string.store_failed)
        }
    }

    /** ស្កេនបញ្ជី app ឡើងវិញ (ឧ. បន្ទាប់ពីដំឡើងហ្គេមថ្មីពី Play Store) */
    private fun refreshApps() {
        if (!revealed) return
        Thread {
            val items = try {
                queryLaunchables()
            } catch (e: Exception) {
                null
            }
            if (items != null) {
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (items.map { it.packageName } != allItems.map { it.packageName }) {
                        allItems = items
                        applyFilter()
                    }
                    if (overlayMode == 1) openOverlay(1)
                }
            }
        }.start()
    }

    private fun toast(resId: Int) {
        Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- splash

    private fun startSplash() {
        // ចាក់ open-app (gif) ព្រមជាមួយសំឡេង gspace_open_sound — ស៊ីគ្នាតាមទីតាំងសំឡេង
        intro = IntroPlayer(this, ivIntro, prefs.getBoolean(Prefs.SOUND, true)) {
            animDone = true
            tryReveal()
        }
        // រង់ចាំ layout រួចសិនទើបចាប់ផ្ដើម ដើម្បីកុំឲ្យ frame ដំបូងគាំង
        ivIntro.post { intro?.start() }
    }

    private fun tryReveal() {
        if (revealed || !loadDone || !animDone || isFinishing || isDestroyed) return
        revealed = true

        applyFilter()
        splash.animate().alpha(0f).setDuration(500).withEndAction {
            splash.visibility = View.GONE
        }.start()

        val dist = dp(70).toFloat()
        val decel = DecelerateInterpolator(1.6f)
        rail.translationX = -dist
        panel.translationX = dist
        topBar.translationY = -dist / 2f
        rv.translationY = dist / 2f

        // ពិនិត្យ update ស្ងាត់ៗ បន្ទាប់ពី lobby បង្ហាញ
        if (prefs.getBoolean(Prefs.AUTO_UPDATE, true)) {
            rv.postDelayed({ updater.check(false) }, 1200)
        }

        rail.animate().translationX(0f).alpha(1f).setDuration(650).setInterpolator(decel).start()
        panel.animate().translationX(0f).alpha(1f).setDuration(650).setInterpolator(decel).start()
        topBar.animate().translationY(0f).alpha(1f).setDuration(600).setStartDelay(100).setInterpolator(decel).start()
        rv.animate().translationY(0f).alpha(1f).setDuration(700).setStartDelay(150).setInterpolator(decel).start()
    }

    // -------------------------------------------------------------- lifecycle

    override fun onPause() {
        OverlayService.lobbyVisible = false
        intro?.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        OverlayService.lobbyVisible = true
        intro?.resume()
        pendingLaunch?.let { p ->
            pendingLaunch = null
            launchPackage(p)
        }
        updater.resumePending()
        refreshApps()
    }

    override fun onDestroy() {
        intro?.release()
        glowAnim?.cancel()
        super.onDestroy()
    }
}
