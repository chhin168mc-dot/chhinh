#include "game.h"
#include <cstdlib>
#include <algorithm>
#include <android/log.h>

#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, "GameZombie", __VA_ARGS__))

Game::Game(int w, int h) : width(w), height(h), spawnTimer(0), score(0), coinsEarned(0), shooting(false), shootCooldown(0) {
    player = {0, 0, 0, 0, 0, 100, 0.4f, true, 0};
    // spawn a few zombies
    for (int i = 0; i < 5; i++) spawnZombie();
}

Game::~Game() {}

void Game::spawnZombie() {
    Entity z;
    float angle = (rand() % 360) * 3.14159f / 180.0f;
    float dist = 8.0f + (rand() % 10);
    z.x = cosf(angle) * dist;
    z.y = 0;
    z.z = sinf(angle) * dist;
    z.vx = z.vy = 0;
    z.hp = 30 + rand() % 20;
    z.size = 0.5f;
    z.alive = true;
    z.type = 1;
    zombies.push_back(z);
}

void Game::fireBullet() {
    if (shootCooldown > 0) return;
    Entity b;
    // simple forward from player (camera looking -z roughly)
    b.x = player.x;
    b.y = player.y + 0.3f;
    b.z = player.z;
    // direction toward touch or default forward
    b.vx = 0;
    b.vy = 0;
    // for prototype: shoot in direction of movement or fixed
    float speed = 15.0f;
    // simple: shoot forward relative to player facing (assume facing -z)
    b.vx = 0;
    b.vy = 0; // we use x/z plane
    // actually store direction in vx/vz, but Entity has vx/vy. reuse
    b.vx = 0.0f; // will set properly
    // Better: store dir in vx (x) and vy (z)
    b.vx = 0.0f;
    b.vy = -speed; // forward -z
    b.hp = 1;
    b.size = 0.15f;
    b.alive = true;
    b.type = 2;
    bullets.push_back(b);
    shootCooldown = 0.25f;
}

void Game::onTouch(float x, float y, bool down) {
    shooting = down;
    // simple virtual joystick / look: map touch to player movement for prototype
    float nx = (x / width) * 2.0f - 1.0f;
    float ny = (y / height) * 2.0f - 1.0f;
    player.vx = nx * 4.0f;
    // for look we ignore for now
    if (down && shootCooldown <= 0) {
        fireBullet();
    }
}

void Game::update(float dt) {
    // player move
    player.x += player.vx * dt;
    player.z += player.vy * dt; // reuse vy as vz for simplicity in this prototype
    // clamp
    if (player.x > 20) player.x = 20;
    if (player.x < -20) player.x = -20;
    if (player.z > 20) player.z = 20;
    if (player.z < -20) player.z = -20;

    if (shootCooldown > 0) shootCooldown -= dt;
    if (shooting) fireBullet();

    // zombies AI: move toward player
    for (auto& z : zombies) {
        if (!z.alive) continue;
        float dx = player.x - z.x;
        float dz = player.z - z.z;
        float dist = sqrtf(dx*dx + dz*dz);
        if (dist > 0.1f) {
            z.x += (dx / dist) * 1.5f * dt;
            z.z += (dz / dist) * 1.5f * dt;
        }
        // damage player if close
        if (dist < 0.8f) {
            player.hp -= 20 * dt;
            if (player.hp <= 0) {
                player.alive = false;
                // simple restart
                player.hp = 100;
                player.alive = true;
                player.x = player.z = 0;
                score = 0;
            }
        }
    }

    // bullets
    for (auto& b : bullets) {
        if (!b.alive) continue;
        b.x += b.vx * dt;
        b.z += b.vy * dt; // vy used as vz
        // lifetime
        b.hp -= dt;
        if (b.hp <= 0) b.alive = false;

        // hit zombies
        for (auto& z : zombies) {
            if (!z.alive) continue;
            float dx = b.x - z.x;
            float dz = b.z - z.z;
            if (dx*dx + dz*dz < (z.size + b.size)*(z.size + b.size)) {
                z.hp -= 25;
                b.alive = false;
                if (z.hp <= 0) {
                    z.alive = false;
                    score += 10;
                    coinsEarned += 5;
                }
                break;
            }
        }
    }

    // clean dead
    zombies.erase(std::remove_if(zombies.begin(), zombies.end(),
        [](const Entity& e){ return !e.alive; }), zombies.end());
    bullets.erase(std::remove_if(bullets.begin(), bullets.end(),
        [](const Entity& e){ return !e.alive; }), bullets.end());

    // spawn more
    spawnTimer += dt;
    if (spawnTimer > 2.0f && zombies.size() < 15) {
        spawnZombie();
        spawnTimer = 0;
    }
}

void Game::render(Renderer* r) {
    // simple top-down-ish or first person cubes
    // Ground
    r->drawCube(0, -0.5f, 0, 40.0f, 0.1f, 40.0f, 0.2f, 0.3f, 0.15f);

    // Player (green)
    r->drawCube(player.x, 0.3f, player.z, player.size, 0.8f, player.size, 0.1f, 0.8f, 0.2f);

    // Gun indication (small cube in front)
    r->drawCube(player.x, 0.5f, player.z - 0.4f, 0.1f, 0.1f, 0.3f, 0.3f, 0.3f, 0.3f);

    // Zombies (red)
    for (const auto& z : zombies) {
        if (z.alive)
            r->drawCube(z.x, 0.4f, z.z, z.size, 0.9f, z.size, 0.7f, 0.1f, 0.1f);
    }

    // Bullets (yellow)
    for (const auto& b : bullets) {
        if (b.alive)
            r->drawCube(b.x, 0.4f, b.z, b.size, b.size, b.size, 1.0f, 1.0f, 0.2f);
    }
}
