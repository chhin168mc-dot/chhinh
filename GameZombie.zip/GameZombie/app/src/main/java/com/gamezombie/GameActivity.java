package com.gamezombie;

import android.app.NativeActivity;
import android.os.Bundle;
import android.view.WindowManager;

public class GameActivity extends NativeActivity {
    static {
        System.loadLibrary("gamezombie");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Force landscape + immersive
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onCreate(savedInstanceState);
    }
}
