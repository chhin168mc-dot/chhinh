package com.gamezombie;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.media.SoundPool;
import android.media.AudioAttributes;

public class MainActivity extends Activity {

    private TextView coinText;
    private int coins = 100;
    private SoundPool soundPool;
    private int clickSoundId;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Force landscape + fullscreen immediately
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("GameZombie", MODE_PRIVATE);
        coins = prefs.getInt("coins", 100);

        coinText = findViewById(R.id.coinText);
        updateCoins();

        // Sound
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        // Note: real sound files would go in res/raw. For size we skip embedding large files.
        // clickSoundId = soundPool.load(this, R.raw.click, 1);

        Button playBtn = findViewById(R.id.playButton);
        Button shopBtn = findViewById(R.id.shopButton);
        Button eventShopBtn = findViewById(R.id.eventShopButton);

        playBtn.setOnClickListener(v -> {
            playClick();
            // Launch native game
            Intent intent = new Intent(this, GameActivity.class);
            startActivity(intent);
        });

        shopBtn.setOnClickListener(v -> {
            playClick();
            setContentView(R.layout.activity_shop);
            setupShop();
        });

        eventShopBtn.setOnClickListener(v -> {
            playClick();
            Toast.makeText(this, "Event Shop coming soon!", Toast.LENGTH_SHORT).show();
        });
    }

    private void setupShop() {
        TextView shopCoins = findViewById(R.id.shopCoinText);
        shopCoins.setText(getString(R.string.coins, coins));

        Button back = findViewById(R.id.backButton);
        back.setOnClickListener(v -> {
            playClick();
            setContentView(R.layout.activity_main);
            coinText = findViewById(R.id.coinText);
            updateCoins();
            // re-bind buttons (simple way)
            findViewById(R.id.playButton).setOnClickListener(vv -> {
                playClick();
                startActivity(new Intent(this, GameActivity.class));
            });
            findViewById(R.id.shopButton).setOnClickListener(vv -> {
                playClick();
                setContentView(R.layout.activity_shop);
                setupShop();
            });
        });

        // Example buy buttons
        findViewById(R.id.buyAmmo).setOnClickListener(v -> {
            if (coins >= 50) {
                coins -= 50;
                prefs.edit().putInt("coins", coins).apply();
                shopCoins.setText(getString(R.string.coins, coins));
                Toast.makeText(this, "Bought Ammo Pack!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Not enough coins!", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.buyHealth).setOnClickListener(v -> {
            if (coins >= 80) {
                coins -= 80;
                prefs.edit().putInt("coins", coins).apply();
                shopCoins.setText(getString(R.string.coins, coins));
                Toast.makeText(this, "Bought Health Pack!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Not enough coins!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateCoins() {
        if (coinText != null) {
            coinText.setText(getString(R.string.coins, coins));
        }
    }

    private void playClick() {
        // if (clickSoundId != 0) soundPool.play(clickSoundId, 1, 1, 0, 0, 1);
    }

    @Override
    protected void onDestroy() {
        if (soundPool != null) soundPool.release();
        super.onDestroy();
    }
}
