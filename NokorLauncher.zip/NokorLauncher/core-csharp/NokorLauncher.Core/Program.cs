using System.Text;
using NokorLauncher.Core;

Console.OutputEncoding = new UTF8Encoding(false);
var (cmd, opt) = Cli.Parse(args);

try
{
    switch (cmd)
    {
        case "versions":
            await Installer.ListVersionsAsync();
            break;

        case "install":
            await new Installer(opt.Req("root")).InstallAsync(opt.Req("version"));
            Out.Emit(new { type = "done" });
            break;

        case "offline":
            Out.Emit(new { type = "account", account = Accounts.Offline(opt.Req("name")) });
            break;

        case "ms-login":
            var acct = await MicrosoftAuth.LoginAsync(opt.Req("client-id"),
                (code, uri) => Out.Emit(new { type = "device_code", userCode = code, uri }));
            Out.Emit(new { type = "account", account = acct });
            break;

        case "ms-refresh":
            var refreshed = await MicrosoftAuth.RefreshAsync(opt.Req("client-id"),
                Environment.GetEnvironmentVariable("NOKOR_REFRESH") ?? throw new Exception("NOKOR_REFRESH not set"));
            Out.Emit(new { type = "account", account = refreshed });
            break;

        case "launch":
            return await GameLauncher.LaunchAsync(opt.Req("root"), opt.Req("version"), opt);

        default:
            Out.Emit(new { type = "error", message = $"unknown command '{cmd}'" });
            return 2;
    }
    return 0;
}
catch (Exception ex)
{
    Out.Emit(new { type = "error", message = ex.Message });
    return 1;
}
