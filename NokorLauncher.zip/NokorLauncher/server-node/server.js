'use strict';
// NokorLauncher update backend (Node.js + Express)
//   GET  /api/health
//   GET  /api/update?app=com.nokorlauncher.mc&version=20.26.1.0&platform=win32
//   POST /api/admin/release   (header x-admin-key, JSON body = new releases.json)
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const APP_ID = 'com.nokorlauncher.mc';
const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.NOKOR_ADMIN_KEY || '';
const FILE = path.join(__dirname, 'releases.json');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '64kb' }));

const load = () => JSON.parse(fs.readFileSync(FILE, 'utf8'));

// Compare "20.26.1.0"-style versions numerically. Returns -1, 0, 1.
function cmp(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x < y ? -1 : 1;
  }
  return 0;
}

// Tiny in-memory rate limit: 60 requests / minute / IP.
const hits = new Map();
app.use((req, res, next) => {
  const now = Date.now(), ip = req.ip;
  const arr = (hits.get(ip) || []).filter(t => now - t < 60000);
  arr.push(now); hits.set(ip, arr);
  if (arr.length > 60) return res.status(429).json({ error: 'rate limited' });
  next();
});

app.get('/api/health', (_req, res) => res.json({ ok: true, app: APP_ID }));

app.get('/api/update', (req, res) => {
  const { app: appId, version, platform } = req.query;
  if (appId !== APP_ID) return res.status(400).json({ error: 'unknown app' });
  if (!/^\d+(\.\d+){1,3}$/.test(String(version || ''))) return res.status(400).json({ error: 'bad version' });
  const rel = load();
  const dl = rel.downloads[String(platform)] || null;
  res.json({
    updateAvailable: cmp(version, rel.latest) < 0,
    mandatory: cmp(version, rel.minimum) < 0,
    latest: rel.latest,
    notes: rel.notes,
    url: dl && dl.url,
    sha256: dl && dl.sha256,
  });
});

app.post('/api/admin/release', (req, res) => {
  const given = Buffer.from(String(req.get('x-admin-key') || ''));
  const want = Buffer.from(ADMIN_KEY);
  if (!ADMIN_KEY || given.length !== want.length || !crypto.timingSafeEqual(given, want))
    return res.status(401).json({ error: 'unauthorized' });
  const b = req.body;
  if (!b || b.app !== APP_ID || !/^\d+(\.\d+){1,3}$/.test(String(b.latest)) || typeof b.downloads !== 'object')
    return res.status(400).json({ error: 'invalid release document' });
  fs.writeFileSync(FILE, JSON.stringify(b, null, 2));
  res.json({ ok: true, latest: b.latest });
});

app.listen(PORT, () => console.log(`NokorLauncher update server on :${PORT}`));
