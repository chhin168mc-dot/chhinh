#pragma once
#include <vector>
#include <cmath>
#include "renderer.h"

struct Entity {
    float x, y, z;
    float vx, vy;
    float hp;
    float size;
    bool alive;
    int type; // 0=player, 1=zombie, 2=bullet
};

class Game {
public:
    Game(int w, int h);
    ~Game();

    void update(float dt);
    void render(Renderer* r);
    void onTouch(float x, float y, bool down);

private:
    int width, height;
    Entity player;
    std::vector<Entity> zombies;
    std::vector<Entity> bullets;
    float spawnTimer;
    int score;
    int coinsEarned;
    bool shooting;
    float shootCooldown;

    void spawnZombie();
    void fireBullet();
};
