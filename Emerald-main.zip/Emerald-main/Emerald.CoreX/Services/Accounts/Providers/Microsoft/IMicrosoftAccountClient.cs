using CmlLib.Core.Auth;
using Emerald.CoreX.Models;

namespace Emerald.CoreX.Services.Auth.Microsoft;

internal interface IMicrosoftAccountClient
{
    Task InitializeAsync(string clientId, string accountStorePath);

    IReadOnlyList<MicrosoftAccountInfo> GetAccounts();

    string? GetDefaultAccountIdentifier();

    Task<MicrosoftInteractiveSignInResult> SignInInteractivelyAsync(CancellationToken cancellationToken = default);

    Task<MSession> AuthenticateAsync(string accountIdentifier);

    Task SignOutAsync(string accountIdentifier);
}

internal sealed record MicrosoftAccountInfo(
    string Identifier,
    string Name,
    string UUID,
    DateTime LastAccess,
    string? SkinUrl = null,
    MinecraftSkinVariant SkinVariant = MinecraftSkinVariant.Classic);

internal sealed record MicrosoftInteractiveSignInResult(
    string? Identifier,
    string? Username,
    string? UUID);
