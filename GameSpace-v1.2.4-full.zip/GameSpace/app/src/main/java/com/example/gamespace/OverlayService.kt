package com.example.gamespace

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.app.ActivityManager
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Overlay ពេលកំពុងលេងហ្គេម/ប្រើ app:
 *  - សញ្ញា (bubble) នៅគែមអេក្រង់ អូសបាន
 *  - ចុចសញ្ញា → ផ្ទាំង TPS (ហ្គេមប៉ុណ្ណោះ) + ស្ថានភាព + បញ្ជី app សម្រាប់អេក្រង់បំបែក + ប៊ូតុង +
 *  - ទាំងអស់ជា window អណ្ដែត ដូច្នេះមិនចាំបាច់ចេញពីហ្គេមទេ
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var panelBody: LinearLayout? = null

    private var trackedPkg = ""
    private var trackedLabel = ""
    private var isGame = false
    private var lastFg: String? = null
    private var homePkgs: Set<String> = emptySet()

    private var tvTps: TextView? = null
    private var tvStatus: TextView? = null
    private var tvRam: TextView? = null
    private var tvBattery: TextView? = null
    private var tvTemp: TextView? = null
    private var tvPing: TextView? = null
    private var tvNet: TextView? = null

    // TPS (frames per second ដែលវាស់ពី Choreographer)
    private var frames = 0
    private var windowStart = 0L
    private var tps = 0
    private var tpsRunning = false
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!tpsRunning) return
            val nowMs = frameTimeNanos / 1_000_000L
            if (windowStart == 0L) windowStart = nowMs
            frames++
            val dt = nowMs - windowStart
            if (dt >= 1000) {
                tps = (frames * 1000f / dt).toInt()
                frames = 0
                windowStart = nowMs
                updateTps()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    @Volatile
    private var pingMs = -1
    private var pingBusy = false

    private val ticker = object : Runnable {
        override fun run() {
            pollForeground()
            if (panel != null) refreshStats()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        @Suppress("DEPRECATION")
        homePkgs = packageManager.queryIntentActivities(home, 0).map { it.activityInfo.packageName }.toSet()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!canDraw(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val pkg = intent?.getStringExtra(EXTRA_PKG).orEmpty()
        if (pkg.isNotEmpty()) track(pkg, intent?.getBooleanExtra(EXTRA_IS_GAME, false) ?: false)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------- foreground

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.ov_notif_title), NotificationManager.IMPORTANCE_MIN)
            )
        }
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = b.setSmallIcon(R.drawable.ic_games)
            .setContentTitle(getString(R.string.ov_notif_title))
            .setContentText(getString(R.string.ov_notif_text))
            .addAction(Notification.Action.Builder(null, getString(R.string.ov_close_overlay), stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------------------------------------------------- tracking

    private fun track(pkg: String, game: Boolean) {
        trackedPkg = pkg
        isGame = game
        lastFg = pkg
        SplitLauncher.splitActive = false
        trackedLabel = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg
        }
        hidePanel()
        removeBubble()
        addBubble()
    }

    private fun pollForeground() {
        if (lobbyVisible) {
            bubble?.visibility = View.GONE
            if (panel != null) hidePanel()
            return
        }
        if (!hasUsageAccess(this)) {
            bubble?.visibility = View.VISIBLE
            return
        }
        try {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = usm.queryEvents(now - 15_000, now)
            val e = UsageEvents.Event()
            var last: String? = null
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                @Suppress("DEPRECATION")
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
            }
            if (last != null) lastFg = last
        } catch (_: Exception) {
        }
        val fg = lastFg
        val hide = fg == packageName || (fg != null && fg in homePkgs)
        bubble?.visibility = if (hide) View.GONE else View.VISIBLE
        if (hide && panel != null) hidePanel()
    }

    // -------------------------------------------------------------- bubble

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun addBubble() {
        val size = dp(46)
        val root = FrameLayout(this)
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#B3062433"))
            setStroke(dp(2), Color.parseColor("#CC4DD0E1"))
        }
        root.background = bg
        root.alpha = 0.78f
        val iv = ImageView(this).apply {
            setPadding(dp(7), dp(7), dp(7), dp(7))
            setImageDrawable(IconLoader.installedIcon(this@OverlayService, trackedPkg))
        }
        root.addView(iv, FrameLayout.LayoutParams(size, size))

        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = -size / 3          // ពាក់កណ្ដាលចូលក្នុងគែមខាងឆ្វេង
        lp.y = screenH() / 3

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        root.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    root.alpha = 1f
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt().coerceIn(0, screenH() - size)
                        safeUpdate(root, lp)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    root.alpha = 0.78f
                    if (!moved && ev.actionMasked == MotionEvent.ACTION_UP) {
                        togglePanel()
                    } else {
                        // ទាញជាប់គែមជិតបំផុត (ពាក់កណ្ដាលលាក់)
                        val toRight = lp.x + size / 2 > screenW() / 2
                        lp.x = if (toRight) screenW() - size + size / 3 else -size / 3
                        safeUpdate(root, lp)
                    }
                }
            }
            true
        }
        try {
            wm.addView(root, lp)
            bubble = root
            bubbleLp = lp
        } catch (_: Exception) {
        }
    }

    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    // --------------------------------------------------------------- panel

    private fun togglePanel() {
        if (panel != null) hidePanel() else showPanel()
    }

    private fun circleButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#2C2C2E"))
                setStroke(dp(1), Color.parseColor("#48484A"))
            }
            elevation = dp(4).toFloat()
            setOnClickListener { onClick() }
        }

    private fun showPanel() {
        val btn = dp(48)
        val gap = dp(8)
        val cardW = min(dp(280), screenW() - btn - gap - dp(16))
        val h = min(dp(380), screenH() - dp(24))

        // Dark Hyperboost-style panel (matching the video)
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val card = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(Color.parseColor("#1C1C1E"))
                setStroke(dp(1), Color.parseColor("#333333"))
            }
            elevation = dp(10).toFloat()
        }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        scroll.addView(body)
        card.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(card, LinearLayout.LayoutParams(cardW, h))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(circleButton("+") { buildPicker() }, LinearLayout.LayoutParams(btn, btn).apply { topMargin = dp(8) })
        col.addView(circleButton("✕") { hidePanel() }, LinearLayout.LayoutParams(btn, btn).apply { topMargin = gap })
        root.addView(col, LinearLayout.LayoutParams(btn, -2).apply { leftMargin = gap })
        panelBody = body

        val lp = WindowManager.LayoutParams(
            cardW + gap + btn, h, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = max(dp(8), (screenH() - h) / 2)

        root.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_OUTSIDE) hidePanel()
            false
        }
        try {
            wm.addView(root, lp)
            panel = root
        } catch (_: Exception) {
            return
        }
        buildMain()
        startTps()
        refreshStats()
    }

    private fun hidePanel() {
        stopTps()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        panelBody = null
        tvTps = null; tvStatus = null; tvRam = null; tvBattery = null
        tvTemp = null; tvPing = null; tvNet = null
    }

    private fun text(s: String, sizeSp: Float, color: String, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = sizeSp
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun statRow(label: String): Pair<LinearLayout, TextView> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(3), 0, dp(3))
        }
        val l = text(label, 12f, "#6B7280").apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val v = text("–", 12f, "#1F2937", true).apply { gravity = Gravity.END; maxLines = 1 }
        row.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(v, LinearLayout.LayoutParams(-2, -2))
        return row to v
    }

    private fun buildMain() {
        val body = panelBody ?: return
        body.removeAllViews()

        // Header: yellow folder + HYPERBOOST + battery/temp (like video)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        val folder = text("📁", 18f, "#FFD60A").apply { setPadding(0, 0, dp(6), 0) }
        head.addView(folder)
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text("HYPERBOOST", 13f, "#FFFFFF", true))
        val st = text(trackedLabel, 10f, "#8E8E93")
        tvStatus = st
        titles.addView(st)
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))

        // Battery + Temp on right of header
        val batCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        val batTv = text("–%", 11f, "#FFFFFF", true)
        tvBattery = batTv
        batCol.addView(batTv)
        val tempTv = text("–°C", 11f, "#FF9F0A", true)
        tvTemp = tempTv
        batCol.addView(tempTv)
        head.addView(batCol)
        body.addView(head)

        // Big FPS + diamond (core of the video look)
        val fpsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(8))
        }
        val fpsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val fpsNum = text("--", 42f, "#FFFFFF", true)
        tvTps = fpsNum
        fpsBox.addView(fpsNum)
        fpsBox.addView(text("fps", 12f, "#8E8E93"))
        fpsRow.addView(fpsBox, LinearLayout.LayoutParams(0, -2, 1f))

        // Glowing diamond / performance gem
        val gem = text("◆", 36f, "#5E5CE6").apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1C1C3A"))
                setStroke(dp(2), Color.parseColor("#5E5CE6"))
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        fpsRow.addView(gem, LinearLayout.LayoutParams(dp(64), dp(64)))
        body.addView(fpsRow)

        // Quick mode chips (like the two tabs in video)
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(10))
        }
        fun chip(label: String, selected: Boolean): TextView {
            return text(label, 11f, if (selected) "#FFFFFF" else "#8E8E93", selected).apply {
                setPadding(dp(12), dp(6), dp(12), dp(6))
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(if (selected) Color.parseColor("#0A84FF") else Color.parseColor("#2C2C2E"))
                }
            }
        }
        chipRow.addView(chip("បង្ហាញលេង", true), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        chipRow.addView(chip("ស្ថានភាព", false), LinearLayout.LayoutParams(0, -2, 1f))
        body.addView(chipRow)

        // 2x3 action grid (matching the 6 buttons in the video)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val actions = listOf(
            Triple("🎤", "បិទមីក", "#3A3A3C"),
            Triple("📞", "បើកហៅ", "#3A3A3C"),
            Triple("🎮", "បង្កើនល្បឿន", "#3A3A3C"),
            Triple("📹", "កំណត់ថត", "#30D158"),
            Triple("🖼️", "រូបថត", "#3A3A3C"),
            Triple("🔒", "ចាក់សោ", "#3A3A3C")
        )
        for (i in 0 until 3) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 0, 0, dp(6))
            }
            for (j in 0 until 2) {
                val (emoji, label, bg) = actions[i * 2 + j]
                val cell = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(6), dp(10), dp(6), dp(10))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(Color.parseColor(bg))
                    }
                    setOnClickListener {
                        Toast.makeText(this@OverlayService, label, Toast.LENGTH_SHORT).show()
                    }
                }
                cell.addView(text(emoji, 20f, "#FFFFFF").apply { gravity = Gravity.CENTER })
                cell.addView(text(label, 10f, "#EBEBF5").apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
                row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    if (j == 0) rightMargin = dp(6)
                })
            }
            grid.addView(row)
        }
        body.addView(grid)

        // RAM / Ping / Net compact row
        val (rRam, vRam) = statRowDark(getString(R.string.ov_ram)); tvRam = vRam
        val (rPing, vPing) = statRowDark(getString(R.string.ov_ping)); tvPing = vPing
        val (rNet, vNet) = statRowDark(getString(R.string.ov_net)); tvNet = vNet
        listOf(rRam, rPing, rNet).forEach { body.addView(it) }

        // Apps for split-screen
        body.addView(text(getString(R.string.ov_apps), 12f, "#0A84FF", true).apply { setPadding(0, dp(10), 0, dp(6)) })
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val rowApps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hs.addView(rowApps)
        for (pkg in Prefs.addedApps(this)) {
            val icon2 = IconLoader.installedIcon(this, pkg) ?: continue
            rowApps.addView(appTile(pkg, icon2))
        }
        if (rowApps.childCount == 0) {
            rowApps.addView(text(getString(R.string.ov_empty), 11f, "#8E8E93"))
        }
        body.addView(hs)

        // Close
        body.addView(text(getString(R.string.ov_close_overlay), 12f, "#FF453A", true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(2))
            setOnClickListener { stopSelf() }
        })
    }

    private fun statRowDark(label: String): Pair<LinearLayout, TextView> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(3), 0, dp(3))
        }
        val l = text(label, 12f, "#8E8E93").apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val v = text("–", 12f, "#FFFFFF", true).apply { gravity = Gravity.END; maxLines = 1 }
        row.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(v, LinearLayout.LayoutParams(-2, -2))
        return row to v
    }

    private fun appTile(pkg: String, icon: Drawable): View {
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, dp(10), 0)
        }
        col.addView(ImageView(this).apply { setImageDrawable(icon) }, LinearLayout.LayoutParams(dp(46), dp(46)))
        col.addView(text(label, 9f, "#8E8E93").apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(54), -2))
        col.setOnClickListener {
            hidePanel()
            SplitLauncher.launch(this, pkg)
        }
        col.setOnLongClickListener {
            Prefs.removeApp(this, pkg)
            Toast.makeText(this, R.string.ov_removed, Toast.LENGTH_SHORT).show()
            buildMain(); refreshStats()
            true
        }
        return col
    }

    private fun plusTile(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val plus = text("+", 24f, "#FFFFFF", true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#0A84FF")) }
        }
        col.addView(plus, LinearLayout.LayoutParams(dp(46), dp(46)))
        col.addView(text(getString(R.string.ov_add), 9f, "#8E8E93").apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(dp(54), -2))
        col.setOnClickListener { buildPicker() }
        return col
    }

    /** បញ្ជី app ដែលអាចបន្ថែម — បង្ហាញក្នុងផ្ទាំងដដែល មិនចេញពីហ្គេម */
    private fun buildPicker() {
        val body = panelBody ?: return
        body.removeAllViews()
        tvTps = null; tvStatus = null; tvRam = null; tvBattery = null; tvTemp = null; tvPing = null; tvNet = null
        body.addView(text("‹  " + getString(R.string.ov_back), 14f, "#0A84FF", true).apply {
            setPadding(0, 0, 0, dp(8))
            setOnClickListener { buildMain(); refreshStats() }
        })
        val loading = text("…", 12f, "#8E8E93")
        body.addView(loading)
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val list = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName && it.activityInfo.packageName != trackedPkg }
                .distinctBy { it.activityInfo.packageName }
                .filter { it.activityInfo.packageName !in Prefs.addedApps(this) }
                .map { Triple(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .sortedBy { it.second.lowercase() }
            handler.post {
                val b = panelBody ?: return@post
                b.removeView(loading)
                for ((pkg, label, ic) in list) {
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, dp(5), 0, dp(5))
                    }
                    row.addView(ImageView(this).apply { setImageDrawable(ic) }, LinearLayout.LayoutParams(dp(34), dp(34)))
                    row.addView(text(label, 13f, "#FFFFFF").apply { setPadding(dp(10), 0, 0, 0) },
                        LinearLayout.LayoutParams(0, -2, 1f))
                    row.setOnClickListener {
                        Prefs.addApp(this, pkg)
                        buildMain(); refreshStats()
                    }
                    b.addView(row)
                }
            }
        }.start()
    }

    // --------------------------------------------------------------- stats

    private fun refreshStats() {
        val state = if (!hasUsageAccess(this) || lastFg == trackedPkg)
            getString(R.string.ov_running) else getString(R.string.ov_background)
        tvStatus?.text = "$trackedLabel · $state"

        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        tvRam?.text = "${mi.availMem / 1048576} / ${mi.totalMem / 1048576} MB"

        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bi != null) {
            val level = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val charging = bi.getIntExtra(BatteryManager.EXTRA_STATUS, 0).let {
                it == BatteryManager.BATTERY_STATUS_CHARGING || it == BatteryManager.BATTERY_STATUS_FULL
            }
            tvBattery?.text = (if (level >= 0) level * 100 / scale else 0).toString() + "%" + if (charging) " ⚡" else ""
            tvTemp?.text = String.format("%.0f°C", temp)
            tvTemp?.setTextColor(Color.parseColor(if (temp >= 42f) "#FF453A" else if (temp >= 38f) "#FF9F0A" else "#30D158"))
        }

        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        tvNet?.text = when {
            caps == null -> getString(R.string.ov_offline)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> getString(R.string.ov_mobile)
            else -> "…"
        }

        tvPing?.text = if (pingMs >= 0) "$pingMs ms" else "…"
        if (!pingBusy) {
            pingBusy = true
            Thread {
                val t0 = System.nanoTime()
                pingMs = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 53), 1500) }
                    ((System.nanoTime() - t0) / 1_000_000L).toInt()
                } catch (_: Exception) {
                    -1
                }
                pingBusy = false
            }.start()
        }
    }

    private fun startTps() {
        if (!isGame || tpsRunning) return
        tpsRunning = true
        frames = 0
        windowStart = 0L
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    private fun stopTps() {
        tpsRunning = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
    }

    private fun updateTps() {
        val v = tvTps ?: return
        v.text = tps.toString()
        v.setTextColor(Color.parseColor(if (tps >= 50) "#30D158" else if (tps >= 30) "#FFFFFF" else "#FF453A"))
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        removeBubble()
        SplitLauncher.splitActive = false
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PKG = "pkg"
        const val EXTRA_IS_GAME = "is_game"
        const val ACTION_STOP = "com.example.gamespace.STOP_OVERLAY"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 77

        /** true ពេលអេក្រង់ GameSpace កំពុងបង្ហាញ — លាក់សញ្ញា */
        @Volatile
        var lobbyVisible = false

        fun canDraw(ctx: Context): Boolean =
            Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(ctx)

        fun hasUsageAccess(ctx: Context): Boolean = try {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            @Suppress("DEPRECATION")
            val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }

        fun start(ctx: Context, pkg: String, isGame: Boolean) {
            val i = Intent(ctx, OverlayService::class.java)
                .putExtra(EXTRA_PKG, pkg)
                .putExtra(EXTRA_IS_GAME, isGame)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }
}
