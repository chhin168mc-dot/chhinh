#!/usr/bin/env bash
# Build everything on Linux / macOS.  Needs: gcc, g++, JDK 17+, .NET 8 SDK, Node 18+, Python 3.10+
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/native build/java/classes build/core

case "$(uname)" in
  Darwin) LIB=libnokorhash.dylib ;;
  *)      LIB=libnokorhash.so ;;
esac

echo "[C]    native SHA-1 library";  gcc -O2 -shared -fPIC -o "build/native/$LIB" native-c/nokorhash.c
echo "[C++]  system info probe";     g++ -O2 -std=c++17 -o build/native/nokor_sysinfo native-cpp/sysinfo.cpp
echo "[Java] NokorBoot wrapper";     javac -d build/java/classes java/nokor/NokorBoot.java
                                     jar cf build/java/nokor-boot.jar -C build/java/classes .
echo "[C#]   core service";          dotnet publish core-csharp/NokorLauncher.Core -c Release -o build/core
                                     cp "build/native/$LIB" build/core/
echo "[Node] update server deps";    (cd server-node && npm install --omit=dev)
echo "[Py]   UI deps";               python3 -m pip install -r ui-python/requirements.txt

echo
echo "Done.   Update server:  node server-node/server.js"
echo "        Launcher UI:    python3 ui-python/main.py"
