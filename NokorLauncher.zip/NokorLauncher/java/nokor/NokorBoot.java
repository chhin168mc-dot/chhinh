package nokor;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * NokorLauncher boot wrapper (Java).
 * Usage: java -cp <game classpath>:nokor-boot.jar nokor.NokorBoot <realMainClass> <game args...>
 * Works with vanilla, OptiFine, Fabric/Quilt (Knot) and Forge main classes.
 */
public final class NokorBoot {
    private NokorBoot() {}

    public static void main(String[] args) throws Throwable {
        if (args.length < 1) {
            System.err.println("[NokorBoot] missing main class");
            System.exit(2);
        }
        String mainClass = args[0];
        String[] rest = Arrays.copyOfRange(args, 1, args.length);

        System.setProperty("nokor.launcher", "NokorLauncher");
        System.setProperty("nokor.appid", "com.nokorlauncher.mc");
        System.out.println("[NokorBoot] " + mainClass + " | Java " + System.getProperty("java.version")
                + " | " + System.getProperty("os.name") + " " + System.getProperty("os.arch"));

        Class<?> c = Class.forName(mainClass, true, Thread.currentThread().getContextClassLoader());
        Method m = c.getMethod("main", String[].class);
        try {
            m.invoke(null, (Object) rest);
        } catch (InvocationTargetException e) {
            throw e.getCause() != null ? e.getCause() : e;
        }
    }
}
