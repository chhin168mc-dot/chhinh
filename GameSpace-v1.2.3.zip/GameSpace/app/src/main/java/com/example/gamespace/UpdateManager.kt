package com.example.gamespace

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * ពិនិត្យ update ពី GitHub Releases (latest) ដោយស្វ័យប្រវត្តិ។
 * គ្រាន់តែដូរ `appVersion` ក្នុង app/build.gradle.kts (ឧ. 1.1.1 → 1.1.2) រួច push
 * → GitHub Actions ចេញ Release ថ្មី → user ឃើញ dialog "មានកំណែថ្មី" ក្នុង app
 * → ចុច "ធ្វើបច្ចុប្បន្នភាព" app ទាញយក APK ហើយបើកការដំឡើងឲ្យតែម្ដង។
 */
class UpdateManager(private val activity: AppCompatActivity) {

    private class Info(val version: String, val apkUrl: String, val notes: String)

    private var pendingApk: File? = null
    private var checking = false

    fun currentVersion(): String = try {
        activity.packageManager.getPackageInfo(activity.packageName, 0).versionName ?: "0"
    } catch (e: Exception) {
        "0"
    }

    /** manual = true → បង្ហាញ toast ពេលគ្មាន update / បរាជ័យ */
    fun check(manual: Boolean) {
        val repo = activity.getString(R.string.github_repo)
        if (repo.contains("YOUR_")) {
            if (manual) toast(R.string.update_not_configured)
            return
        }
        if (checking) return
        checking = true
        Thread {
            val info = try {
                fetchLatest(repo)
            } catch (e: Exception) {
                null
            }
            activity.runOnUiThread {
                checking = false
                if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
                when {
                    info == null -> if (manual) toast(R.string.update_failed)
                    isNewer(info.version, currentVersion()) -> showDialog(info)
                    manual -> toast(R.string.update_latest)
                }
            }
        }.start()
    }

    /** ហៅពី onResume — បន្តដំឡើងបន្ទាប់ពី user អនុញ្ញាត "unknown sources" */
    fun resumePending() {
        val f = pendingApk ?: return
        if (canInstall()) {
            pendingApk = null
            install(f)
        }
    }

    private fun fetchLatest(repo: String): Info? {
        GitHubBackend.fetchVersion(repo)?.let { v ->
            return Info(v.version, v.apkUrl, v.notes)
        }
        val conn = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            if (conn.responseCode != 200) return null
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(text)
            val tag = json.getString("tag_name")
            val notes = json.optString("body", "")
            val assets = json.getJSONArray("assets")
            var apk: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) {
                    apk = a.getString("browser_download_url")
                    break
                }
            }
            return if (apk == null) null else Info(tag.removePrefix("v"), apk, notes)
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        /** ប្រៀបធៀប "1.0.1" > "1.0.0" */
        fun isNewer(remote: String, local: String): Boolean {
            fun parse(s: String): List<Int> =
                s.trim().removePrefix("v").split(".").map { part ->
                    part.takeWhile { it.isDigit() }.toIntOrNull() ?: 0
                }
            val a = parse(remote)
            val b = parse(local)
            for (i in 0 until maxOf(a.size, b.size)) {
                val x = a.getOrElse(i) { 0 }
                val y = b.getOrElse(i) { 0 }
                if (x != y) return x > y
            }
            return false
        }
    }

    private fun showDialog(info: Info) {
        val notes = info.notes.trim().take(600)
        AlertDialog.Builder(activity)
            .setTitle(activity.getString(R.string.update_title, info.version))
            .setMessage(activity.getString(R.string.update_message, currentVersion(), info.version, notes))
            .setPositiveButton(R.string.update_now) { _, _ -> download(info) }
            .setNegativeButton(R.string.update_later, null)
            .show()
    }

    private fun download(info: Info) {
        val density = activity.resources.displayMetrics.density
        val pad = (24 * density).toInt()
        val bar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = true
        }
        val box = FrameLayout(activity).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(
                bar,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        val dlg = AlertDialog.Builder(activity)
            .setTitle(R.string.update_downloading)
            .setView(box)
            .setCancelable(false)
            .create()
        dlg.show()

        Thread {
            try {
                val dir = File(activity.cacheDir, "updates")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val out = File(dir, "GameSpace.apk")

                val conn = URL(info.apkUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.instanceFollowRedirects = true
                val total = conn.contentLengthLong
                var lastPct = -1
                conn.inputStream.use { input ->
                    out.outputStream().use { output ->
                        val buf = ByteArray(32 * 1024)
                        var done = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != lastPct) {
                                    lastPct = pct
                                    activity.runOnUiThread {
                                        bar.isIndeterminate = false
                                        bar.progress = pct
                                    }
                                }
                            }
                        }
                    }
                }
                conn.disconnect()
                activity.runOnUiThread {
                    dlg.dismiss()
                    install(out)
                }
            } catch (e: Exception) {
                activity.runOnUiThread {
                    dlg.dismiss()
                    toast(R.string.update_failed)
                }
            }
        }.start()
    }

    private fun canInstall(): Boolean =
        Build.VERSION.SDK_INT < 26 || activity.packageManager.canRequestPackageInstalls()

    private fun install(file: File) {
        if (!canInstall()) {
            pendingApk = file
            toast(R.string.update_allow_install)
            val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            activity.startActivity(i)
            return
        }
        try {
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
        } catch (e: Exception) {
            toast(R.string.update_failed)
        }
    }

    private fun toast(res: Int) {
        Toast.makeText(activity, res, Toast.LENGTH_LONG).show()
    }
}
