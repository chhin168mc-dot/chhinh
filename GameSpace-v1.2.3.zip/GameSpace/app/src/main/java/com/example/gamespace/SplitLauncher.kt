package com.example.gamespace

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast

/**
 * បើក app មួយទៀតជា "អេក្រង់បំបែក" ដោយមិនបិទ app/ហ្គេមដែលកំពុងលេង។
 *
 * វិធី A (ល្អបំផុត): បើបានបើក Accessibility របស់ GameSpace → បំបែកអេក្រង់ម្ដង
 *                    រួចបើក app ទៅផ្នែកម្ខាងទៀត (FLAG_ACTIVITY_LAUNCH_ADJACENT)
 * វិធី B: ទូរស័ព្ទគាំទ្រ freeform → បើកជាបង្អួចអណ្ដែតផ្នែកខាងស្ដាំ
 * បើគ្មានវិធីណាមួយ → មិនបើកពេញអេក្រង់ទេ (កុំឲ្យចេញពីហ្គេម) តែបង្ហាញសារ ហើយបើកទំព័រ Accessibility
 */
object SplitLauncher {
    private val main = Handler(Looper.getMainLooper())

    /** true ពេលយើងបានបំបែកអេក្រង់រួចហើយក្នុង session នេះ */
    @Volatile
    var splitActive = false

    fun launch(ctx: Context, pkg: String) {
        val pm = ctx.packageManager
        val base = pm.getLaunchIntentForPackage(pkg)
        if (base == null) {
            toast(ctx, R.string.toast_open_failed)
            return
        }
        base.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        // របៀប 0 = បង្អួចអណ្ដែតពីលើហ្គេម (ដូចរូបភាព) · របៀប 1 = អេក្រង់បំបែក
        if (Prefs.of(ctx).getInt(Prefs.WINDOW_MODE, 0) == 0) {
            if (!floatingSupported(ctx)) toast(ctx, R.string.toast_need_freeform)
            launchFloating(ctx, base)
        } else {
            launchSplit(ctx, base)
        }
    }

    /** ពិនិត្យថាទូរស័ព្ទអាចបើកបង្អួចអណ្ដែតបាន — បើមិនអាច នឹងមិនបើកពេញអេក្រង់ (កុំឲ្យចេញពីហ្គេម) */
    private fun floatingSupported(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        if (ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)) return true
        return try {
            val r = ctx.contentResolver
            Settings.Global.getInt(r, "enable_freeform_support", 0) == 1 ||
                Settings.Global.getInt(r, "force_resizable_activities", 0) == 1
        } catch (_: Exception) {
            false
        }
    }

    /** បើក app ជាបង្អួចអណ្ដែត (freeform) នៅលើហ្គេម ដោយហ្គេមនៅតែដំណើរការ */
    private fun launchFloating(ctx: Context, intent: Intent) {
        val m = ctx.resources.displayMetrics
        val w = (m.widthPixels * 0.42f).toInt()
        val h = (m.heightPixels * 0.92f).toInt()
        val left = (m.widthPixels * 0.04f).toInt()
        val top = (m.heightPixels - h) / 2
        val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(left, top, left + w, top + h))
        // WINDOWING_MODE_FREEFORM = 5 (API លាក់ — សាកល្បងតាម reflection)
        try {
            ActivityOptions::class.java
                .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                .invoke(opts, 5)
        } catch (_: Throwable) {
        }
        start(ctx, intent, opts.toBundle())
    }

    private fun launchSplit(ctx: Context, base: Intent) {
        val pm = ctx.packageManager
        base.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)

        val svc = SplitAccessibilityService.instance
        if (svc != null) {
            if (!splitActive) {
                splitActive = svc.toggleSplit()
                main.postDelayed({ start(ctx, base, null) }, 900)
            } else {
                start(ctx, base, null)
            }
            return
        }

        if (Build.VERSION.SDK_INT >= 24 &&
            pm.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
        ) {
            val m = ctx.resources.displayMetrics
            val opts = ActivityOptions.makeBasic()
                .setLaunchBounds(Rect(m.widthPixels / 2, 0, m.widthPixels, m.heightPixels))
            start(ctx, base, opts.toBundle())
            return
        }

        toast(ctx, R.string.toast_need_accessibility)
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    private fun start(ctx: Context, intent: Intent, options: android.os.Bundle?) {
        try {
            ctx.startActivity(intent, options)
        } catch (_: Exception) {
            toast(ctx, R.string.toast_open_failed)
        }
    }

    private fun toast(ctx: Context, res: Int) {
        Toast.makeText(ctx.applicationContext, res, Toast.LENGTH_LONG).show()
    }
}
