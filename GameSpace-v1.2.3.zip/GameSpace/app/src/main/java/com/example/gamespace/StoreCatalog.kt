package com.example.gamespace

data class StoreGame(
    val name: String,
    val packageName: String,
    val tag: String,
    val iconUrl: String? = null
)

/** បញ្ជីហ្គេមពេញនិយម — ចុច "ដំឡើង" នឹងបើក Google Play, ចុច "បើក" បើបានដំឡើងរួច */
object StoreCatalog {
    val games = listOf(
        StoreGame("Free Fire", "com.dts.freefireth", "Battle Royale"),
        StoreGame("Free Fire MAX", "com.dts.freefiremax", "Battle Royale"),
        StoreGame("Mobile Legends: Bang Bang", "com.mobile.legends", "MOBA"),
        StoreGame("PUBG MOBILE", "com.tencent.ig", "Battle Royale"),
        StoreGame("Call of Duty: Mobile", "com.activision.callofduty.shooter", "FPS"),
        StoreGame("Minecraft", "com.mojang.minecraftpe", "Sandbox"),
        StoreGame("Roblox", "com.roblox.client", "Sandbox"),
        StoreGame("Genshin Impact", "com.miHoYo.GenshinImpact", "RPG"),
        StoreGame("Clash of Clans", "com.supercell.clashofclans", "Strategy"),
        StoreGame("Among Us", "com.innersloth.spacemafia", "Party")
    )
}
