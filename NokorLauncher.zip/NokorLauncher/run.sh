#!/usr/bin/env bash
# Start NokorLauncher from a release package (Linux / macOS). Needs Python 3.10+, .NET 8 runtime, Java.
cd "$(dirname "$0")"
python3 -m pip install -q -r ui-python/requirements.txt
exec python3 ui-python/main.py
