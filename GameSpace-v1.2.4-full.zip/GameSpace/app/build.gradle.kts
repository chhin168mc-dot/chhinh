plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ====================================================================
//  ដូរតែលេខ version នៅទីនេះ (ឧ. "1.1.1" → "1.1.2") រួច push ទៅ GitHub
//  GitHub Actions នឹងចេញ Release ថ្មី ហើយ user នឹងឃើញការជូនដំណឹង Update
// ====================================================================
val appVersion = "1.2.4"
val appVersionCode = appVersion.split(".").map { it.toInt() }
    .let { it[0] * 10000 + it[1] * 100 + it[2] }

android {
    namespace = "com.example.gamespace"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.gamespace"
        minSdk = 24
        targetSdk = 34
        versionCode = appVersionCode
        versionName = appVersion

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // keystore ថេរ — ត្រូវប្រើដដែលរាល់ build ទើប update ពីលើ app ចាស់បាន
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    testOptions {
        animationsDisabled = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    testImplementation("junit:junit:4.13.2")

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test:rules:1.6.1")
}
