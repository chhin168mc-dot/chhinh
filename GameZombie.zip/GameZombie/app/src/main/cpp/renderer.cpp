#include "renderer.h"
#include <cmath>
#include <android/log.h>

#define LOGE(...) ((void)__android_log_print(ANDROID_LOG_ERROR, "GameZombie", __VA_ARGS__))

static const char* vsSrc = R"(
attribute vec3 aPos;
uniform mat4 uMVP;
void main() {
    gl_Position = uMVP * vec4(aPos, 1.0);
}
)";

static const char* fsSrc = R"(
precision mediump float;
uniform vec3 uColor;
void main() {
    gl_FragColor = vec4(uColor, 1.0);
}
)";

static float cubeVerts[] = {
    // front
    -0.5f,-0.5f, 0.5f,  0.5f,-0.5f, 0.5f,  0.5f, 0.5f, 0.5f,
    -0.5f,-0.5f, 0.5f,  0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f,
    // back
    -0.5f,-0.5f,-0.5f, -0.5f, 0.5f,-0.5f,  0.5f, 0.5f,-0.5f,
    -0.5f,-0.5f,-0.5f,  0.5f, 0.5f,-0.5f,  0.5f,-0.5f,-0.5f,
    // left
    -0.5f,-0.5f,-0.5f, -0.5f,-0.5f, 0.5f, -0.5f, 0.5f, 0.5f,
    -0.5f,-0.5f,-0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f,-0.5f,
    // right
     0.5f,-0.5f,-0.5f,  0.5f, 0.5f,-0.5f,  0.5f, 0.5f, 0.5f,
     0.5f,-0.5f,-0.5f,  0.5f, 0.5f, 0.5f,  0.5f,-0.5f, 0.5f,
    // top
    -0.5f, 0.5f,-0.5f, -0.5f, 0.5f, 0.5f,  0.5f, 0.5f, 0.5f,
    -0.5f, 0.5f,-0.5f,  0.5f, 0.5f, 0.5f,  0.5f, 0.5f,-0.5f,
    // bottom
    -0.5f,-0.5f,-0.5f,  0.5f,-0.5f,-0.5f,  0.5f,-0.5f, 0.5f,
    -0.5f,-0.5f,-0.5f,  0.5f,-0.5f, 0.5f, -0.5f,-0.5f, 0.5f,
};

Renderer::Renderer(int w, int h) : width(w), height(h), program(0), vbo(0) {
    initShaders();
    setupCube();
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.05f, 0.05f, 0.1f, 1.0f);
}

Renderer::~Renderer() {
    if (program) glDeleteProgram(program);
    if (vbo) glDeleteBuffers(1, &vbo);
}

void Renderer::initShaders() {
    GLuint vs = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vs, 1, &vsSrc, NULL);
    glCompileShader(vs);

    GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &fsSrc, NULL);
    glCompileShader(fs);

    program = glCreateProgram();
    glAttachShader(program, vs);
    glAttachShader(program, fs);
    glLinkProgram(program);

    glDeleteShader(vs);
    glDeleteShader(fs);

    posLoc = glGetAttribLocation(program, "aPos");
    colorLoc = glGetUniformLocation(program, "uColor");
    mvpLoc = glGetUniformLocation(program, "uMVP");
}

void Renderer::setupCube() {
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVerts), cubeVerts, GL_STATIC_DRAW);
}

void Renderer::beginFrame() {
    glViewport(0, 0, width, height);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram(program);
}

void Renderer::endFrame() {
    // nothing extra
}

// Simple perspective + lookAt matrix (column major)
static void mat4_perspective(float* m, float fovy, float aspect, float znear, float zfar) {
    float f = 1.0f / tanf(fovy * 0.5f * 3.14159265f / 180.0f);
    m[0] = f / aspect; m[1] = 0; m[2] = 0; m[3] = 0;
    m[4] = 0; m[5] = f; m[6] = 0; m[7] = 0;
    m[8] = 0; m[9] = 0; m[10] = (zfar + znear) / (znear - zfar); m[11] = -1;
    m[12] = 0; m[13] = 0; m[14] = (2 * zfar * znear) / (znear - zfar); m[15] = 0;
}

static void mat4_lookat(float* m, float ex, float ey, float ez, float cx, float cy, float cz) {
    float fx = cx - ex, fy = cy - ey, fz = cz - ez;
    float len = sqrtf(fx*fx + fy*fy + fz*fz);
    fx /= len; fy /= len; fz /= len;
    // up = 0,1,0
    float sx = fy * 0 - fz * 1; // cross
    float sy = fz * 0 - fx * 0;
    float sz = fx * 1 - fy * 0;
    len = sqrtf(sx*sx + sy*sy + sz*sz);
    if (len > 0.0001f) { sx /= len; sy /= len; sz /= len; }
    float ux = sy * fz - sz * fy;
    float uy = sz * fx - sx * fz;
    float uz = sx * fy - sy * fx;

    m[0] = sx; m[1] = ux; m[2] = -fx; m[3] = 0;
    m[4] = sy; m[5] = uy; m[6] = -fy; m[7] = 0;
    m[8] = sz; m[9] = uz; m[10] = -fz; m[11] = 0;
    m[12] = -(sx*ex + sy*ey + sz*ez);
    m[13] = -(ux*ex + uy*ey + uz*ez);
    m[14] = -(-fx*ex -fy*ey -fz*ez);
    m[15] = 1;
}

static void mat4_mul(float* r, const float* a, const float* b) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            r[i*4 + j] = a[i*4+0]*b[0*4+j] + a[i*4+1]*b[1*4+j] + a[i*4+2]*b[2*4+j] + a[i*4+3]*b[3*4+j];
        }
    }
}

void Renderer::drawCube(float x, float y, float z, float sx, float sy, float sz, float r, float g, float b) {
    float proj[16], view[16], model[16], mvp[16], tmp[16];

    mat4_perspective(proj, 60.0f, (float)width / height, 0.1f, 100.0f);

    // Camera behind and above player-ish (simple fixed for prototype)
    // For better feel we put camera at player + offset
    mat4_lookat(view, x, y + 3.0f, z + 6.0f, x, y, z);

    // Model = scale + translate
    for (int i = 0; i < 16; i++) model[i] = 0;
    model[0] = sx; model[5] = sy; model[10] = sz; model[15] = 1;
    model[12] = x; model[13] = y; model[14] = z;

    mat4_mul(tmp, view, model);
    mat4_mul(mvp, proj, tmp);

    glUniformMatrix4fv(mvpLoc, 1, GL_FALSE, mvp);
    glUniform3f(colorLoc, r, g, b);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glEnableVertexAttribArray(posLoc);
    glVertexAttribPointer(posLoc, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glDrawArrays(GL_TRIANGLES, 0, 36);
    glDisableVertexAttribArray(posLoc);
}
