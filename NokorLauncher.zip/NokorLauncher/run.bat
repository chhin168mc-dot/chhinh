@echo off
REM Start NokorLauncher from a release package (Windows). Needs Python 3.10+, .NET 8 runtime, Java.
cd /d "%~dp0"
python -m pip install -q -r ui-python\requirements.txt
python ui-python\main.py
