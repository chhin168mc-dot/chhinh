"""NokorLauncher 20.26.1.0  (com.nokorlauncher.mc) - Python UI + animations."""
import json
import sys
import urllib.parse
import urllib.request

from PySide6.QtCore import (QAbstractAnimation, QEvent, QPropertyAnimation, QSequentialAnimationGroup, QPauseAnimation,
                            QProcess, Qt, QTimer, QUrl)
from PySide6.QtGui import QDesktopServices, QGuiApplication, QIcon, QPixmap
from PySide6.QtWidgets import (QApplication, QFileDialog, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel,
                               QMessageBox, QPushButton, QVBoxLayout, QWidget)

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
from nokor import config as C                                             # noqa: E402
from nokor.animations import (AnimatedBackground, FadeStack, LogoWidget, NokorButton, RippleOverlay,  # noqa: E402
                              ShimmerProgressBar)
from nokor.core_client import CoreJob                                     # noqa: E402
from nokor.pages import AccountsPage, HomePage, ModsPage, SettingsPage, VersionsPage  # noqa: E402
from nokor.sound import SoundManager                                      # noqa: E402
from nokor.theme import STYLE                                             # noqa: E402
from nokor.workers import Worker                                          # noqa: E402

NAV = ["Play", "Download Version", "Mods and Resources", "Settings", "Accounts"]


class MainWindow(AnimatedBackground):
    def __init__(self):
        super().__init__()
        self.cfg = C.Settings()
        self.sound = SoundManager(self.cfg["sound"], self.cfg["volume"] / 100)
        NokorButton.click_hook = lambda: self.sound.play("button.ogg")
        self.busy, self._jobs, self._workers, self._err = False, [], [], None

        self.setWindowTitle(f"{C.APP_NAME} {C.APP_VERSION}")
        self.setWindowIcon(QIcon(str(C.LOGO)))
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.resize(1120, 700)
        self.setMinimumSize(960, 620)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ---- sidebar
        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(250)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(20, 28, 20, 20)
        sl.setSpacing(10)
        self.logo = LogoWidget(QPixmap(str(C.LOGO)), 170)
        sl.addWidget(self.logo, 0, Qt.AlignmentFlag.AlignHCenter)
        brand = QLabel("NOKOR LAUNCHER")
        brand.setObjectName("brand")
        brand.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ver = QLabel(f"v{C.APP_VERSION}  ·  {C.APP_ID}")
        ver.setObjectName("muted")
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sl.addWidget(brand)
        sl.addWidget(ver)
        sl.addSpacing(14)
        self.nav_btns = []
        for i, label in enumerate(NAV):
            b = NokorButton(label, primary=(i == 0))
            b.clicked.connect(lambda _=False, i=i: self.nav(i))
            sl.addWidget(b)
            self.nav_btns.append(b)
        sl.addStretch()
        outer.addWidget(side)

        # ---- right side
        right = QVBoxLayout()
        right.setContentsMargins(0, 8, 8, 14)
        top = QHBoxLayout()
        top.addStretch()
        for txt, fn in (("—", self.showMinimized), ("✕", self.close)):
            b = QPushButton(txt)
            b.setObjectName("winbtn")
            b.clicked.connect(fn)
            top.addWidget(b)
        right.addLayout(top)

        self.home, self.versions = HomePage(self), VersionsPage(self)
        self.mods, self.settings = ModsPage(self), SettingsPage(self)
        self.accounts = AccountsPage(self)
        self.stack = FadeStack()
        for p in (self.home, self.versions, self.mods, self.settings, self.accounts):
            self.stack.addWidget(p)
        right.addWidget(self.stack, 1)

        self.dock = QWidget()                      # download animation dock
        dl = QVBoxLayout(self.dock)
        dl.setContentsMargins(40, 0, 40, 0)
        dl.setSpacing(4)
        self.dock_lbl = QLabel()
        self.dock_lbl.setObjectName("muted")
        self.bar = ShimmerProgressBar()
        dl.addWidget(self.dock_lbl)
        dl.addWidget(self.bar)
        self.dock.hide()
        right.addWidget(self.dock)
        outer.addLayout(right, 1)

        self.ripple = RippleOverlay(self)          # click animation
        self.toast_lbl = QLabel(self)
        self.toast_lbl.setStyleSheet("background:rgba(20,20,22,0.95); border:1px solid #ff5a36; border-radius:10px; padding:10px 18px;")
        self.toast_lbl.hide()
        self.toast_fx = QGraphicsOpacityEffect(self.toast_lbl)
        self.toast_lbl.setGraphicsEffect(self.toast_fx)
        QApplication.instance().installEventFilter(self)

    # ------------------------------------------------------------ window plumbing
    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.ripple.setGeometry(self.rect())
        self.ripple.raise_()
        self.toast_lbl.adjustSize()
        self.toast_lbl.move((self.width() - self.toast_lbl.width()) // 2 + 120, self.height() - 100)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and e.position().y() < 56 and self.windowHandle():
            self.windowHandle().startSystemMove()
        super().mousePressEvent(e)

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.MouseButtonPress and isinstance(obj, QWidget) and obj.window() is self:
            self.ripple.ripple(self.ripple.mapFromGlobal(ev.globalPosition().toPoint()))
        return False

    def start(self):
        """Open animation: window fade-in, logo pop, open.ogg then background.ogg."""
        self.setWindowOpacity(0.0)
        self.show()
        self._open = QPropertyAnimation(self, b"windowOpacity", self)
        self._open.setDuration(650)
        self._open.setStartValue(0.0)
        self._open.setEndValue(1.0)
        self._open.start()
        self.logo.play_intro()
        self.sound.play("open.ogg")
        QTimer.singleShot(900, self.sound.start_background)
        self.versions.load()
        self.check_update()

    def nav(self, i):
        for k, b in enumerate(self.nav_btns):
            b.primary = (k == i)
            b.update()
        self.stack.go(i)

    def toast(self, text):
        self.toast_lbl.setText(text)
        self.toast_lbl.adjustSize()
        self.toast_lbl.move((self.width() - self.toast_lbl.width()) // 2 + 120, self.height() - 100)
        self.toast_lbl.show()
        self.toast_lbl.raise_()
        g = QSequentialAnimationGroup(self)
        for dur, a, b in ((220, 0.0, 1.0), (None, 0, 0), (450, 1.0, 0.0)):
            if dur is None:
                g.addAnimation(QPauseAnimation(2600))
                continue
            an = QPropertyAnimation(self.toast_fx, b"opacity")
            an.setDuration(dur)
            an.setStartValue(a)
            an.setEndValue(b)
            g.addAnimation(an)
        g.finished.connect(self.toast_lbl.hide)
        self._toast_anim = g
        g.start()

    # ------------------------------------------------------------ core / workers
    def run_core(self, args, env=None):
        job = CoreJob(list(args) + ["--root", str(C.ROOT)], env, self)
        self._jobs.append(job)
        job.finished.connect(lambda *_: self._jobs.remove(job) if job in self._jobs else None)
        job.start()
        return job

    def run_worker(self, fn, ok, fail):
        w = Worker(fn, self)
        w.done.connect(ok)
        w.failed.connect(fail)
        w.finished.connect(lambda: self._workers.remove(w) if w in self._workers else None)
        self._workers.append(w)
        w.start()
        return w

    # ------------------------------------------------------------ download animation dock
    def begin_task(self, label):
        self.busy = True
        self.dock.show()
        self.dock_lbl.setText(label)
        self.bar.setValue(0, "", immediate=True)
        self.set_boost(1.0)

    def update_task(self, pct, text=None):
        self.bar.setValue(pct, text or "")

    def end_task(self, label="Done", ok=True):
        self.busy = False
        self.set_boost(0.0)
        self.dock_lbl.setText(label)
        if ok:
            self.bar.setValue(100)
        QTimer.singleShot(1200, lambda: None if self.busy else self.dock.hide())

    # ------------------------------------------------------------ versions
    def installed_versions(self):
        d = C.ROOT / "versions"
        return sorted((p.name for p in d.iterdir() if (p / f"{p.name}.json").exists()), reverse=True) if d.exists() else []

    def is_installed(self, vid):
        return (C.ROOT / "versions" / vid / ".nokor_ok").exists()

    def select_version(self, vid):
        self.cfg["last_version"] = vid
        self.cfg.save()
        self.home.refresh()
        self.toast(f"Selected {vid}")

    def install(self, vid, then=None):
        if self.busy:
            return self.toast("Another task is running")
        self._err = None
        self.begin_task(f"Downloading Minecraft {vid}")
        job = self.run_core(["install", "--version", vid])

        def msg(m):
            t = m.get("type")
            if t == "progress":
                self.update_task(m["percent"])
            elif t == "error":
                self._err = m["message"]

        def fin(code):
            if code == 0 and not self._err:
                self.end_task("Installed")
                self.versions.refilter()
                self.toast(f"{vid} ready")
                if then:
                    then()
            else:
                self.end_task("Failed", ok=False)
                self.toast("Install failed: " + (self._err or f"exit {code}"))

        job.message.connect(msg)
        job.finished.connect(fin)

    def install_optifine(self, mc):
        def after():
            QDesktopServices.openUrl(QUrl("https://optifine.net/downloads"))
            QGuiApplication.clipboard().setText(str(C.ROOT))
            QMessageBox.information(self, "OptiFine",
                                    f"1) Download OptiFine for Minecraft {mc} from the page that just opened.\n"
                                    f"2) Choose the .jar file in the next window.\n"
                                    f"3) In the OptiFine installer set the folder to:\n{C.ROOT}\n(already copied to clipboard)")
            path, _ = QFileDialog.getOpenFileName(self, "Select OptiFine .jar", "", "Jar (*.jar)")
            if not path:
                return
            p = QProcess(self)
            p.setProgram(self.cfg["java"] or "java")
            p.setArguments(["-jar", path])
            p.finished.connect(lambda *_: (self.versions.refilter(), self.toast("OptiFine installer closed - see 'Installed'")))
            p.errorOccurred.connect(lambda *_: self.toast("Cannot start Java"))
            p.start()

        self.install(mc, then=after)

    # ------------------------------------------------------------ accounts
    def add_account(self, acct):
        accts = self.cfg["accounts"]
        for i, a in enumerate(accts):                      # replace same name+type
            if a["name"] == acct["name"] and a["type"] == acct["type"]:
                accts[i] = acct
                self.cfg["active"] = i
                break
        else:
            accts.append(acct)
            self.cfg["active"] = len(accts) - 1
        self.cfg.save()
        self.accounts.refresh()
        self.home.refresh()
        self.toast(f"Account {acct['name']} ready")

    def login_ms(self):
        cid = self.cfg["client_id"]
        if not cid:
            self.toast("Set your Azure Client ID in Settings first")
            return self.nav(3)
        job = self.run_core(["ms-login", "--client-id", cid])

        def msg(m):
            t = m.get("type")
            if t == "device_code":
                self.accounts.code.setText(f"Open {m['uri']} and enter the code:  {m['userCode']}")
                QGuiApplication.clipboard().setText(m["userCode"])
                QDesktopServices.openUrl(QUrl(m["uri"]))
            elif t == "account":
                self.accounts.code.setText("")
                self.add_account(m["account"])
            elif t == "error":
                self.accounts.code.setText("")
                self.toast(m["message"])

        job.message.connect(msg)

    # ------------------------------------------------------------ play
    def play(self):
        vid, acct = self.cfg["last_version"], self.cfg.active_account()
        if self.busy:
            return
        if not vid:
            self.toast("Choose a version first")
            return self.nav(1)
        if not acct:
            self.toast("Add an Offline or Premium account first")
            return self.nav(4)
        if not self.is_installed(vid):
            return self.install(vid, then=self.play)
        if acct["type"] == "msa":
            self._refresh_then_launch(vid, acct)
        else:
            self._launch(vid, acct)

    def _refresh_then_launch(self, vid, acct):
        self.home.play.setEnabled(False)
        self.home.play.setText("Signing in…")
        job = self.run_core(["ms-refresh", "--client-id", self.cfg["client_id"]],
                            env={"NOKOR_REFRESH": acct.get("refreshToken", "")})
        got = {}

        def msg(m):
            if m.get("type") == "account":
                got["a"] = m["account"]
            elif m.get("type") == "error":
                got["e"] = m["message"]

        def fin(_code):
            if "a" in got:
                self.add_account(got["a"])
                self._launch(vid, got["a"])
            else:
                self._reset_play()
                self.toast(got.get("e", "Sign-in failed"))

        job.message.connect(msg)
        job.finished.connect(fin)

    def _launch(self, vid, acct):
        args = ["launch", "--version", vid, "--name", acct["name"], "--uuid", acct["uuid"],
                "--user-type", "msa" if acct["type"] == "msa" else "legacy",
                "--ram", str(self.cfg["ram"]), "--java", self.cfg["java"] or "java"]
        if self.cfg["use_boot"] and C.BOOT_JAR.exists():
            args += ["--boot", str(C.BOOT_JAR)]
        self.home.log.clear()
        self.home.log.show()
        self.home.play.setEnabled(False)
        self.home.play.setText("Launching…")
        job = self.run_core(args, env={"NOKOR_TOKEN": acct.get("accessToken", "0")})

        def msg(m):
            t = m.get("type")
            if t == "log":
                self.home.log.appendPlainText(m["line"])
            elif t == "started":
                self.home.play.setText("Minecraft is running")
                self.set_boost(0.6)
            elif t == "error":
                self.toast(m["message"])

        job.message.connect(msg)
        job.finished.connect(lambda code: (self._reset_play(), self.toast("Game closed" if code == 0 else f"Game exited ({code})")))

    def _reset_play(self):
        self.set_boost(0.0)
        self.home.play.setEnabled(True)
        self.home.play.setText("▶   Play Game Minecraft")

    # ------------------------------------------------------------ app update (Node.js backend)
    def check_update(self, manual=False):
        url = self.cfg["update_url"].rstrip("/") + "/api/update?" + urllib.parse.urlencode(
            {"app": C.APP_ID, "version": C.APP_VERSION, "platform": sys.platform})

        def fetch(_p):
            req = urllib.request.Request(url, headers={"User-Agent": C.USER_AGENT})
            with urllib.request.urlopen(req, timeout=8) as r:
                return json.load(r)

        def ok(d):
            if d.get("updateAvailable") and d.get("url"):
                b = self.home.banner
                b.setText(f"⬆  Update {d['latest']} available — click to download")
                try:
                    b.clicked.disconnect()
                except RuntimeError:
                    pass
                b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(d["url"])))
                b.show()
                if manual:
                    self.toast("Update available")
            elif manual:
                self.toast("You are up to date")

        self.run_worker(fetch, ok, lambda e: self.toast("Update check failed") if manual else None)

    def open_game_folder(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(C.ROOT)))


def main():
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(C.APP_ID)
    app = QApplication(sys.argv)
    app.setApplicationName(C.APP_NAME)
    app.setApplicationVersion(C.APP_VERSION)
    app.setDesktopFileName(C.APP_ID)
    app.setWindowIcon(QIcon(str(C.LOGO)))
    app.setStyleSheet(STYLE)
    w = MainWindow()
    w.start()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
