using CommonServiceLocator;
using CommunityToolkit.Mvvm.DependencyInjection;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Windows.ApplicationModel.Resources;
using System;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Windows.System.Diagnostics;

namespace Emerald.Helpers;

public static class Extensions
{
    private static readonly ConcurrentDictionary<string, string> cachedResources = new();

    //public static void ShowAt(this TeachingTip tip, FrameworkElement element, TeachingTipPlacementMode placement = TeachingTipPlacementMode.Auto, bool closeWhenClick = true, bool addToMainGrid = true)
    //{
    //    if (addToMainGrid)
    //        (App.Current.MainWindow.Content as Grid).Children.Add(tip);

    //    tip.Target = element;
    //    tip.PreferredPlacement = placement;
    //    tip.IsOpen = true;
    //    if (closeWhenClick)
    //    {
    //        tip.ActionButtonClick += (_, _) => tip.IsOpen = false;
    //        tip.CloseButtonClick += (_, _) => tip.IsOpen = false;
    //    }
    //}

    public static int? GetMemoryGB()
    {
        var _logger = Ioc.Default.GetService<ILogger<SystemMemoryUsageReport>>();
        try
        {
            _logger.LogDebug("Getting device memory");
            var systemMemoryUsageReport = SystemDiagnosticInfo.GetForCurrentSystem()?.MemoryUsage?.GetReport();
            var memkb = Convert.ToInt64(systemMemoryUsageReport?.TotalPhysicalSizeInBytes);

            _logger.LogDebug("Memory: {memkb}", memkb);
            return Convert.ToInt32(memkb / Math.Pow(1024, 3));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to get device memory");
            return null;
        }
    }

    public static string KiloFormat(this int num)
    {
        if (num >= 100000000)
        {
            return (num / 1000000).ToString("#,0M");
        }

        if (num >= 10000000)
        {
            return (num / 1000000).ToString("0.#") + "M";
        }

        if (num >= 100000)
        {
            return (num / 1000).ToString("#,0K");
        }

        if (num >= 1000)
        {
            return (num / 100).ToString("0.#") + "K";
        }

        return num.ToString("#,0");
    }

    public static ContentDialog ToContentDialog(this UIElement content, string title, string closebtnText = null,
        ContentDialogButton defaultButton = ContentDialogButton.Close, bool addScrollBar = true,
        string PrimaryButtonText = null)
    {
        ContentDialog dialog = new()
        {
            XamlRoot = App.Current.MainWindow.Content.XamlRoot,
            Style = Application.Current.Resources["DefaultContentDialogStyle"] as Style,
            Title = title,
            CloseButtonText = closebtnText,
            PrimaryButtonText = PrimaryButtonText,
            DefaultButton = defaultButton,
            Content = addScrollBar
                ? new ScrollViewer
                {
                    Content = content,
                    Padding = new Thickness(12)
                }
                : content,

            RequestedTheme =
                (ElementTheme)Ioc.Default.GetService<Services.SettingsService>().Settings.App.Appearance.Theme
        };
        App.Current.Log().LogInformation("Created ContentDialog with title: {title}", title);
        return dialog;
    }

    public static int Remove<T>(this ObservableCollection<T> coll, Func<T, bool> condition)
    {
        var itemsToRemove = coll.Where(condition).ToList();

        foreach (var itemToRemove in itemsToRemove)
        {
            coll.Remove(itemToRemove);
        }

        return itemsToRemove.Count;
    }

    public static int Remove<T>(this List<T> coll, Func<T, bool> condition)
    {
        var itemsToRemove = coll.Where(condition).ToList();

        foreach (var itemToRemove in itemsToRemove)
        {
            coll.Remove(itemToRemove);
        }

        return itemsToRemove.Count;
    }

    public static void AddRange<T>(this ObservableCollection<T> cll, IEnumerable<T> items)
    {
        foreach (var item in items)
        {
            cll.Add(item);
        }
    }

    public static string ToBinaryString(this string str)
    {
        var binary = "";
        foreach (var ch in str)
        {
            binary += Convert.ToString((int)ch, 2);
        }

        return binary;
    }

    public static string ToMD5(this string s)
    {
        StringBuilder sb = new();
        var hashValue = MD5.HashData(Encoding.UTF8.GetBytes(s));

        foreach (var b in hashValue)
        {
            sb.Append($"{b:X2}");
        }

        return sb.ToString();
    }

    /// <summary>
    /// Stretches the dialog's BackgroundElement to fill the host window.
    /// Call before ShowAsync().
    /// </summary>
    public static void StretchToWindow(this ContentDialog dialog)
    {
        dialog.HorizontalAlignment = HorizontalAlignment.Stretch;
        dialog.VerticalAlignment = VerticalAlignment.Stretch;

        dialog.Loaded += OnLoaded;
    }

    private static void OnLoaded(object sender, RoutedEventArgs e)
    {
        var dialog = (ContentDialog)sender;
        dialog.Loaded -= OnLoaded;

        var bg = FindDescendantByName(dialog, "BackgroundElement") as FrameworkElement;
        if (bg != null)
        {
            bg.HorizontalAlignment = HorizontalAlignment.Stretch;
            bg.MaxWidth = double.PositiveInfinity;
            // Optional — remove corner radius for a truly flat full-screen feel
            // if (bg is Border b) b.CornerRadius = new CornerRadius(0);
        }

        // DialogSpace grid inside BackgroundElement
        var space = FindDescendantByName(dialog, "DialogSpace") as FrameworkElement;
        if (space != null)
        {
            space.HorizontalAlignment = HorizontalAlignment.Stretch;
        }
    }

    private static DependencyObject? FindDescendantByName(DependencyObject parent, string name)
    {
        var count = VisualTreeHelper.GetChildrenCount(parent);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is FrameworkElement fe && fe.Name == name)
            {
                return child;
            }

            var result = FindDescendantByName(child, name);
            if (result != null)
            {
                return result;
            }
        }

        return null;
    }

    //public static string Localize(this Core.Localized resourceKey) =>
    //     resourceKey.ToString().Localize();

    //public static Models.Account ToAccount(this CmlLib.Core.Auth.MSession session, bool plusCount = true)
    //{
    //    bool isOffline = session.AccessToken == "access_token";
    //    return new Models.Account(session.Username, isOffline ? null : session.AccessToken, isOffline ? null : session.UUID, plusCount ? MainWindow.HomePage.AccountsPage.AllCount++ : 0, false, session.ClientToken);
    //}

    //public static CmlLib.Core.Auth.MSession ToMSession(this Models.Account account)
    //{
    //    bool isOffline = account.UUID == null;
    //    return new CmlLib.Core.Auth.MSession(account.UserName, isOffline ? "access_token" : account.AccessToken, isOffline ? Guid.NewGuid().ToString().Replace("-", "") : account.UUID) { ClientToken  = account.ClientToken };
    //}
}
