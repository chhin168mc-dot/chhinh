import copy
import json
import os
import sys
from pathlib import Path

APP_NAME = "NokorLauncher"
APP_VERSION = "20.26.1.0"
APP_ID = "com.nokorlauncher.mc"
UPDATE_SERVER = os.environ.get("NOKOR_UPDATE_URL", "http://localhost:3000")
USER_AGENT = f"NokorLauncher/{APP_VERSION} ({APP_ID})"

if getattr(sys, "frozen", False):                  # PyInstaller build: assets/ and build/ sit next to the exe
    BASE = Path(sys.executable).resolve().parent
else:
    BASE = Path(__file__).resolve().parents[2]
ASSETS = BASE / "assets"
LOGO = ASSETS / "nokormc.png"
SOUNDS = ASSETS / "sounds"          # open.ogg, button.ogg, background.ogg
BUILD = BASE / "build"
EXE = ".exe" if sys.platform == "win32" else ""
BOOT_JAR = BUILD / "java" / "nokor-boot.jar"
SYSINFO = BUILD / "native" / f"nokor_sysinfo{EXE}"
CORE_DLL = BUILD / "core" / "NokorLauncher.Core.dll"
CORE_EXE = BUILD / "core" / f"NokorLauncher.Core{EXE}"   # self-contained build (CI); preferred when present


def _data_dir() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home()))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    d = base / APP_ID
    d.mkdir(parents=True, exist_ok=True)
    return d


DATA = _data_dir()
ROOT = DATA / "minecraft"           # game directory (versions, libraries, assets, mods ...)
ROOT.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = DATA / "settings.json"


class Settings(dict):
    DEFAULTS = {
        "ram": 4096, "java": "", "use_boot": True,
        "sound": True, "volume": 60,
        "client_id": "",                 # your Azure app (client) id for Microsoft login
        "update_url": UPDATE_SERVER,
        "last_version": "",
        "active": -1, "accounts": [],
    }

    def __init__(self):
        super().__init__(copy.deepcopy(self.DEFAULTS))
        try:
            self.update(json.loads(SETTINGS_FILE.read_text("utf-8")))
        except Exception:
            pass

    def save(self):
        tmp = SETTINGS_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(self, indent=2), "utf-8")
        try:
            os.chmod(tmp, 0o600)          # file contains account tokens
        except OSError:
            pass
        tmp.replace(SETTINGS_FILE)

    def active_account(self):
        i = self["active"]
        return self["accounts"][i] if 0 <= i < len(self["accounts"]) else None
