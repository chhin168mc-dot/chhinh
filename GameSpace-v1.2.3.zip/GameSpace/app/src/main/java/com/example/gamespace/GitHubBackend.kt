package com.example.gamespace

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * GitHub Backend (Static JSON API តាមរយៈ raw.githubusercontent.com)
 * - backend/api/version.json : ពិនិត្យ update ដោយគ្មាន rate limit របស់ GitHub API
 * - backend/api/store.json   : បញ្ជីហ្គេមក្នុងហាង (កែលើ GitHub ដោយមិនបាច់ build APK ថ្មី)
 * - backend/api/config.json  : សារជូនដំណឹង និងការកំណត់ពីចម្ងាយ
 */
object GitHubBackend {

    data class VersionInfo(
        val version: String,
        val apkUrl: String,
        val notes: String,
        val forceUpdate: Boolean
    )

    data class RemoteConfig(
        val announcement: String,
        val maintenance: Boolean,
        val minSupportedVersion: String
    )

    @Volatile
    private var cachedStore: List<StoreGame>? = null

    private fun rawUrl(repo: String, path: String): String =
        "https://raw.githubusercontent.com/$repo/main/$path?t=${System.currentTimeMillis() / 60000}"

    private fun getText(urlStr: String): String? {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Cache-Control", "no-cache")
            if (conn.responseCode != 200) return null
            conn.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    fun fetchVersion(repo: String): VersionInfo? {
        if (repo.contains("YOUR_")) return null
        val text = getText(rawUrl(repo, "backend/api/version.json")) ?: return null
        return try {
            val json = JSONObject(text)
            val version = json.optString("version", "")
            val apkUrl = json.optString("apkUrl", "")
            if (version.isBlank() || apkUrl.isBlank()) return null
            VersionInfo(
                version = version,
                apkUrl = apkUrl,
                notes = json.optString("notes", ""),
                forceUpdate = json.optBoolean("forceUpdate", false)
            )
        } catch (_: Exception) {
            null
        }
    }

    fun fetchStore(repo: String, onResult: (List<StoreGame>) -> Unit) {
        cachedStore?.let {
            onResult(it)
            return
        }
        if (repo.contains("YOUR_")) {
            onResult(StoreCatalog.games)
            return
        }
        Thread {
            val list = try {
                val text = getText(rawUrl(repo, "backend/api/store.json"))
                if (text != null) {
                    val arr = JSONObject(text).getJSONArray("games")
                    val parsed = mutableListOf<StoreGame>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        parsed.add(
                            StoreGame(
                                name = o.getString("name"),
                                packageName = o.getString("packageName"),
                                tag = o.optString("tag", "Game"),
                                iconUrl = o.optString("iconUrl", "").ifBlank { null }
                            )
                        )
                    }
                    if (parsed.isNotEmpty()) parsed else StoreCatalog.games
                } else {
                    StoreCatalog.games
                }
            } catch (_: Exception) {
                StoreCatalog.games
            }
            cachedStore = list
            onResult(list)
        }.start()
    }

    fun fetchConfig(repo: String, onResult: (RemoteConfig?) -> Unit) {
        if (repo.contains("YOUR_")) {
            onResult(null)
            return
        }
        Thread {
            val cfg = try {
                val text = getText(rawUrl(repo, "backend/api/config.json")) ?: return@Thread onResult(null)
                val json = JSONObject(text)
                RemoteConfig(
                    announcement = json.optString("announcement", ""),
                    maintenance = json.optBoolean("maintenance", false),
                    minSupportedVersion = json.optString("minSupportedVersion", "1.0.0")
                )
            } catch (_: Exception) {
                null
            }
            onResult(cfg)
        }.start()
    }
}
