# GameZombie - Survival Zombie (Android C++ NDK)

Prototype survival zombie game written mainly in **C++** with Android NDK + OpenGL ES 2.0.

## Features
- **Forced Landscape** orientation on launch
- Lobby with **Play**, **Shop**, **Event Shop** buttons
- Coin system (saved with SharedPreferences)
- Simple 3D world (cubes for player / gun / zombies / bullets)
- Touch to move + auto shoot
- GitHub Actions workflow to build APK

## Requirements
- Android Studio or command line with NDK + CMake
- minSdk 24

## Build locally
```bash
./gradlew assembleDebug
```
APK will be in `app/build/outputs/apk/debug/`

## Build on GitHub
Push to `main` or run the workflow manually. Artifact "GameZombie-APK" will contain the APK.

## Controls (in-game)
- Touch & drag to move player
- Hold touch to shoot

## Notes
This is a **starter / prototype**.  
Real 3D models, animations, sounds, custom maps, proper FPS camera, inventory etc. need to be added later.  
File size stays small because no heavy assets are included.

## Structure
```
app/src/main/
  cpp/          → C++ game + renderer (OpenGL ES)
  java/         → Lobby + Shop UI (MainActivity)
  res/layout/   → XML layouts
```

Made for learning / extending.
