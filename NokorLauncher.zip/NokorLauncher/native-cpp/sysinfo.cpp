// NokorLauncher - system info probe (C++17).
// Prints one JSON object: RAM, CPU cores, recommended Minecraft RAM, detected Java installs.
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>
#include <thread>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
namespace fs = std::filesystem;

static unsigned long long total_ram_mb() {
#ifdef _WIN32
    MEMORYSTATUSEX m; m.dwLength = sizeof(m);
    if (!GlobalMemoryStatusEx(&m)) return 0;
    return m.ullTotalPhys / (1024ull * 1024ull);
#else
    long pages = sysconf(_SC_PHYS_PAGES), size = sysconf(_SC_PAGE_SIZE);
    if (pages < 0 || size < 0) return 0;
    return (unsigned long long)pages * (unsigned long long)size / (1024ull * 1024ull);
#endif
}

static std::string esc(const std::string &s) {
    std::string o;
    for (char c : s) {
        if (c == '\\' || c == '"') { o += '\\'; o += c; }
        else if (c == '\n') o += "\\n";
        else o += c;
    }
    return o;
}

static void probe(const fs::path &dir, std::vector<std::string> &out) {
    std::error_code ec;
    if (!fs::is_directory(dir, ec)) return;
    for (auto &e : fs::directory_iterator(dir, ec)) {
        for (const char *rel : {"bin/java", "bin/java.exe", "Contents/Home/bin/java"}) {
            fs::path p = e.path() / rel;
            if (fs::is_regular_file(p, ec)) { out.push_back(p.string()); break; }
        }
    }
}

int main() {
    unsigned long long ram = total_ram_mb();
    unsigned cores = std::thread::hardware_concurrency();
    // Recommend half the RAM, 2 GB..8 GB, rounded to 512 MB.
    unsigned long long rec = std::clamp<unsigned long long>(ram / 2, 2048, 8192);
    rec = rec / 512 * 512;
    if (ram && rec > ram) rec = ram;

    std::vector<std::string> java;
    if (const char *jh = std::getenv("JAVA_HOME")) {
        for (const char *rel : {"bin/java", "bin/java.exe"}) {
            fs::path p = fs::path(jh) / rel; std::error_code ec;
            if (fs::is_regular_file(p, ec)) java.push_back(p.string());
        }
    }
    for (const char *d : {"C:/Program Files/Java", "C:/Program Files/Eclipse Adoptium", "C:/Program Files/Microsoft",
                          "C:/Program Files/Zulu", "/usr/lib/jvm", "/Library/Java/JavaVirtualMachines"})
        probe(d, java);
    std::sort(java.begin(), java.end());
    java.erase(std::unique(java.begin(), java.end()), java.end());

    std::cout << "{\"total_ram_mb\":" << ram << ",\"cores\":" << cores << ",\"recommended_ram_mb\":" << rec << ",\"java\":[";
    for (size_t i = 0; i < java.size(); i++) std::cout << (i ? "," : "") << "\"" << esc(java[i]) << "\"";
    std::cout << "]}\n";
    return 0;
}
