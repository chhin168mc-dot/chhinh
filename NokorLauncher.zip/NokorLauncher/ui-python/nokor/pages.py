import re

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QPlainTextEdit, QPushButton, QSlider, QVBoxLayout, QWidget)

from . import config as C
from . import modrinth, native
from .animations import NokorButton


def mc_of(version_id: str) -> str:
    """'1.21.11-OptiFine_HD_U_J1' -> '1.21.11'"""
    m = re.match(r"\d+\.\d+(?:\.\d+)?", version_id or "")
    return m.group(0) if m else ""


def _page(win):
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(36, 6, 36, 18)
    lay.setSpacing(12)
    return w, lay


def _title(text):
    l = QLabel(text)
    l.setObjectName("h1")
    return l


def _muted(text=""):
    l = QLabel(text)
    l.setObjectName("muted")
    l.setWordWrap(True)
    return l


# ------------------------------------------------------------------ Play
class HomePage(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        lay = QVBoxLayout(self)
        lay.setContentsMargins(40, 6, 40, 24)
        lay.setSpacing(12)
        self.banner = QPushButton()
        self.banner.setObjectName("banner")
        self.banner.setCursor(Qt.CursorShape.PointingHandCursor)
        self.banner.hide()
        self.sub = _muted()
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(500)
        self.log.setMaximumHeight(150)
        self.log.hide()
        self.play = NokorButton("▶   Play Game Minecraft", primary=True)
        self.play.setMinimumHeight(64)
        f = self.play.font()
        f.setPointSize(16)
        f.setBold(True)
        self.play.setFont(f)
        self.play.clicked.connect(win.play)

        lay.addWidget(self.banner)
        lay.addSpacing(40)
        lay.addWidget(_title("NOKOR LAUNCHER"))
        lay.addWidget(self.sub)
        lay.addStretch()
        lay.addWidget(self.log)
        lay.addWidget(self.play)
        self.refresh()

    def refresh(self):
        a = self.win.cfg.active_account()
        who = f"{a['name']} ({'Premium' if a['type'] == 'msa' else 'Offline'})" if a else "no account"
        self.sub.setText(f"Version: {self.win.cfg['last_version'] or '—'}      Account: {who}")


# ------------------------------------------------------------------ Download Version Minecraft
class VersionsPage(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win, self.items = win, []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(36, 6, 36, 18)
        lay.setSpacing(12)
        lay.addWidget(_title("Download Version Minecraft"))
        row = QHBoxLayout()
        self.kind = QComboBox()
        self.kind.addItems(["Release", "Snapshot", "OptiFine", "Installed"])
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search…  e.g. 1.21.11")
        row.addWidget(self.kind)
        row.addWidget(self.search, 1)
        lay.addLayout(row)
        self.list = QListWidget()
        lay.addWidget(self.list, 1)
        self.note = _muted()
        lay.addWidget(self.note)
        btns = QHBoxLayout()
        self.dl = NokorButton("Download Version Minecraft", primary=True)
        self.use = NokorButton("Use this version")
        btns.addWidget(self.dl, 2)
        btns.addWidget(self.use, 1)
        lay.addLayout(btns)

        self.kind.currentIndexChanged.connect(self.refilter)
        self.search.textChanged.connect(self.refilter)
        self.list.itemDoubleClicked.connect(lambda *_: self.use_selected())
        self.dl.clicked.connect(self.download)
        self.use.clicked.connect(self.use_selected)

    def load(self):
        job = self.win.run_core(["versions"])
        job.message.connect(self._msg)

    def _msg(self, m):
        if m.get("type") == "versions":
            self.items = m["items"]
            self.refilter()
        elif m.get("type") == "error":
            self.win.toast("Version list: " + m["message"])

    def refilter(self):
        k, q = self.kind.currentText(), self.search.text().strip().lower()
        installed = self.win.installed_versions()
        self.note.setText("OptiFine has no public API: the vanilla version is downloaded first, then the official "
                          "OptiFine installer opens. Make sure that version exists on optifine.net."
                          if k == "OptiFine" else "")
        if k == "Installed":
            ids = installed
        else:
            want = "snapshot" if k == "Snapshot" else "release"
            ids = [i["id"] for i in self.items if i["type"] == want]
        self.list.clear()
        for vid in ids:
            if q and q not in vid.lower():
                continue
            label = ("OptiFine " if k == "OptiFine" else "") + vid
            if k != "Installed" and self.win.is_installed(vid) and k != "OptiFine":
                label += "     ✓ installed"
            it = QListWidgetItem(label)
            it.setData(Qt.ItemDataRole.UserRole, vid)
            self.list.addItem(it)

    def _current(self):
        it = self.list.currentItem()
        if not it:
            self.win.toast("Select a version first")
            return None
        return it.data(Qt.ItemDataRole.UserRole)

    def download(self):
        vid = self._current()
        if not vid:
            return
        if self.kind.currentText() == "OptiFine":
            self.win.install_optifine(vid)
        else:
            self.win.install(vid, then=lambda: self.win.select_version(vid))

    def use_selected(self):
        vid = self._current()
        if vid:
            self.win.select_version(vid)


# ------------------------------------------------------------------ Download Mods and Resources pack
KINDS = {"Mods": ("mod", "mods"), "Resource Packs": ("resourcepack", "resourcepacks"), "Shaders": ("shader", "shaderpacks")}


class ModsPage(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        lay = QVBoxLayout(self)
        lay.setContentsMargins(36, 6, 36, 18)
        lay.setSpacing(12)
        lay.addWidget(_title("Download Mods and Resources pack"))
        row = QHBoxLayout()
        self.kind = QComboBox()
        self.kind.addItems(list(KINDS))
        self.loader = QComboBox()
        self.loader.addItems(["fabric", "forge", "neoforge", "quilt"])
        self.ver = QLineEdit()
        self.ver.setPlaceholderText("MC version")
        self.ver.setFixedWidth(110)
        self.q = QLineEdit()
        self.q.setPlaceholderText("Search Modrinth…  e.g. sodium")
        go = NokorButton("Search")
        go.setFixedWidth(110)
        for w in (self.kind, self.loader, self.ver):
            row.addWidget(w)
        row.addWidget(self.q, 1)
        row.addWidget(go)
        lay.addLayout(row)
        self.list = QListWidget()
        lay.addWidget(self.list, 1)
        self.dl = NokorButton("Download selected", primary=True)
        lay.addWidget(self.dl)
        go.clicked.connect(self.search)
        self.q.returnPressed.connect(self.search)
        self.dl.clicked.connect(self.download)
        self.kind.currentTextChanged.connect(lambda t: self.loader.setEnabled(t == "Mods"))

    def showEvent(self, e):
        if not self.ver.text():
            self.ver.setText(mc_of(self.win.cfg["last_version"]))
        super().showEvent(e)

    def search(self):
        kind = KINDS[self.kind.currentText()][0]
        args = (self.q.text().strip(), kind, self.ver.text().strip(), self.loader.currentText())
        self.win.run_worker(lambda _p: modrinth.search(*args), self._fill,
                            lambda err: self.win.toast("Search failed: " + err))

    def _fill(self, hits):
        self.list.clear()
        for h in hits:
            it = QListWidgetItem(f"{h['title']}  —  {h.get('description', '')[:90]}   ⬇ {h.get('downloads', 0):,}")
            it.setData(Qt.ItemDataRole.UserRole, h["project_id"])
            self.list.addItem(it)
        if not hits:
            self.win.toast("No results")

    def download(self):
        it = self.list.currentItem()
        if not it:
            return self.win.toast("Select an item first")
        if self.win.busy:
            return self.win.toast("Another task is running")
        kind, folder = KINDS[self.kind.currentText()]
        pid, mc, loader = it.data(Qt.ItemDataRole.UserRole), self.ver.text().strip(), self.loader.currentText()
        dest = C.ROOT / folder
        self.win.begin_task("Downloading " + self.kind.currentText())

        def done(path):
            self.win.end_task("Saved")
            self.win.toast("Saved to " + path)

        def fail(err):
            self.win.end_task("Failed", ok=False)
            self.win.toast("Download failed: " + err)

        w = self.win.run_worker(lambda prog: modrinth.download(pid, kind, mc, loader, dest, prog), done, fail)
        w.progress.connect(lambda pct, text: self.win.update_task(pct, text))


# ------------------------------------------------------------------ Settings Launcher
class SettingsPage(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        cfg = win.cfg
        info = native.sysinfo()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(36, 6, 36, 18)
        lay.setSpacing(10)
        lay.addWidget(_title("Settings Launcher"))
        lay.addWidget(_muted(f"{info.get('cores', '?')} CPU cores · {info.get('total_ram_mb', 0)} MB RAM · "
                             f"recommended for Minecraft: {info.get('recommended_ram_mb', 4096)} MB"))

        self.ram_lbl = QLabel()
        self.ram = QSlider(Qt.Orientation.Horizontal)
        self.ram.setRange(1024, max(2048, int(info.get("total_ram_mb", 8192))))
        self.ram.setSingleStep(256)
        self.ram.setValue(int(cfg["ram"]))
        self.ram.valueChanged.connect(self._ram)
        self.ram.valueChanged.connect(self._save)
        self._ram(self.ram.value())
        lay.addWidget(self.ram_lbl)
        lay.addWidget(self.ram)

        lay.addWidget(QLabel("Java"))
        jr = QHBoxLayout()
        self.java = QComboBox()
        self.java.setEditable(True)
        self.java.addItems(info.get("java", []))
        self.java.setCurrentText(cfg["java"])
        self.java.lineEdit().setPlaceholderText("java  (uses PATH)")
        b = NokorButton("Browse")
        b.setFixedWidth(110)
        b.clicked.connect(self._browse)
        jr.addWidget(self.java, 1)
        jr.addWidget(b)
        lay.addLayout(jr)
        self.java.editTextChanged.connect(self._save)

        self.boot = QCheckBox("Use NokorBoot (Java wrapper)")
        self.boot.setChecked(cfg["use_boot"])
        self.snd = QCheckBox("Sound (open / button / background)")
        self.snd.setChecked(cfg["sound"])
        self.vol = QSlider(Qt.Orientation.Horizontal)
        self.vol.setRange(0, 100)
        self.vol.setValue(cfg["volume"])
        for w in (self.boot, self.snd):
            w.toggled.connect(self._save)
            lay.addWidget(w)
        lay.addWidget(self.vol)
        self.vol.valueChanged.connect(self._save)

        lay.addWidget(QLabel("Azure Client ID (for Premium / Microsoft login)"))
        self.cid = QLineEdit(cfg["client_id"])
        self.cid.textChanged.connect(self._save)
        lay.addWidget(self.cid)
        lay.addWidget(QLabel("Update server"))
        self.upd = QLineEdit(cfg["update_url"])
        self.upd.textChanged.connect(self._save)
        lay.addWidget(self.upd)
        lay.addStretch()

        row = QHBoxLayout()
        u = NokorButton("Check for updates", primary=True)
        u.clicked.connect(lambda: win.check_update(manual=True))
        o = NokorButton("Open game folder")
        o.clicked.connect(win.open_game_folder)
        row.addWidget(u)
        row.addWidget(o)
        lay.addLayout(row)

    def _ram(self, v):
        v = v // 256 * 256
        self.ram_lbl.setText(f"Memory: {v} MB")

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select java executable")
        if p:
            self.java.setCurrentText(p)

    def _save(self, *_):
        c = self.win.cfg
        c["ram"] = self.ram.value() // 256 * 256
        c["java"] = self.java.currentText().strip()
        c["use_boot"] = self.boot.isChecked()
        c["sound"] = self.snd.isChecked()
        c["volume"] = self.vol.value()
        c["client_id"] = self.cid.text().strip()
        c["update_url"] = self.upd.text().strip()
        c.save()
        self.win.sound.configure(c["sound"], c["volume"] / 100)


# ------------------------------------------------------------------ App Offline account and Premium account
class AccountsPage(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        lay = QVBoxLayout(self)
        lay.setContentsMargins(36, 6, 36, 18)
        lay.setSpacing(12)
        lay.addWidget(_title("Offline account and Premium account"))
        self.list = QListWidget()
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        use = NokorButton("Use selected", primary=True)
        rem = NokorButton("Remove")
        use.clicked.connect(self.use)
        rem.clicked.connect(self.remove)
        row.addWidget(use, 2)
        row.addWidget(rem, 1)
        lay.addLayout(row)

        lay.addWidget(QLabel("Offline account"))
        orow = QHBoxLayout()
        self.name = QLineEdit()
        self.name.setPlaceholderText("Player name (3-16: letters, digits, _)")
        add = NokorButton("Add offline")
        add.clicked.connect(self.add_offline)
        self.name.returnPressed.connect(self.add_offline)
        orow.addWidget(self.name, 1)
        orow.addWidget(add)
        lay.addLayout(orow)

        lay.addWidget(QLabel("Premium account"))
        ms = NokorButton("Sign in with Microsoft")
        ms.clicked.connect(win.login_ms)
        lay.addWidget(ms)
        self.code = _muted()
        lay.addWidget(self.code)
        self.refresh()

    def refresh(self):
        self.list.clear()
        for i, a in enumerate(self.win.cfg["accounts"]):
            mark = "●  " if i == self.win.cfg["active"] else "    "
            self.list.addItem(f"{mark}{a['name']}   —   {'Premium' if a['type'] == 'msa' else 'Offline'}")

    def use(self):
        i = self.list.currentRow()
        if i >= 0:
            self.win.cfg["active"] = i
            self.win.cfg.save()
            self.refresh()
            self.win.home.refresh()

    def remove(self):
        i = self.list.currentRow()
        if i >= 0:
            del self.win.cfg["accounts"][i]
            self.win.cfg["active"] = min(self.win.cfg["active"], len(self.win.cfg["accounts"]) - 1)
            self.win.cfg.save()
            self.refresh()
            self.win.home.refresh()

    def add_offline(self):
        name = self.name.text().strip()
        if not name:
            return
        job = self.win.run_core(["offline", "--name", name])

        def msg(m):
            if m.get("type") == "account":
                self.win.add_account(m["account"])
                self.name.clear()
            elif m.get("type") == "error":
                self.win.toast(m["message"])

        job.message.connect(msg)
