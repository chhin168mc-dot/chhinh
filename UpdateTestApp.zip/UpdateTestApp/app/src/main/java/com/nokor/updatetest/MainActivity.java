package com.nokor.updatetest;

import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView version = new TextView(this);
        version.setTextSize(24);
        version.setText(getString(R.string.main_version, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE));
        root.addView(version, wrap());

        TextView feed = new TextView(this);
        feed.setTextSize(12);
        feed.setPadding(0, pad / 2, 0, pad);
        feed.setText(getString(R.string.main_feed, getString(R.string.update_feed_url)));
        root.addView(feed, wrap());

        SwitchCompat auto = new SwitchCompat(this);
        auto.setText(R.string.main_auto_update);
        auto.setChecked(UpdateManager.prefs(this).getBoolean(UpdateManager.PREF_AUTO_CHECK, true));
        auto.setOnCheckedChangeListener((button, checked) ->
                UpdateManager.prefs(this).edit().putBoolean(UpdateManager.PREF_AUTO_CHECK, checked).apply());
        root.addView(auto, wrap());

        Button check = new Button(this);
        check.setText(R.string.main_check_now);
        check.setOnClickListener(v -> UpdateManager.checkNow(this));
        root.addView(check, wrap());

        setContentView(root);

        UpdateManager.checkOnStartup(this);
    }

    private static LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
}
