# Update Test App

App តូចមួយសម្រាប់សាកល្បង code app update / auto update ។

## របៀបសាកល្បង
1. បង្កើត repo **public** ថ្មីលើ GitHub (raw URL របស់ feed ត្រូវការ public) ហើយ push folder នេះទាំងមូលទៅ branch `main` (ឬ `master`) ។
2. រង់ចាំ workflow **Build and publish test app** ដំណើរការ (build #1) ។ វាបង្កើត release `nightly` ដែលមាន `UpdateTest.apk` និង commit `update/latest_version_md.json` ។
3. ទាញ `UpdateTest.apk` ពី release ដំឡើងលើទូរស័ព្ទ (build #1, code 1) ។
4. កែអ្វីបន្តិចបន្តួច (ឧ. អក្សរក្នុង `strings.xml`) ហើយ push ម្តងទៀត ។ Build #2 បង្កើត feed `code: 2` ។
5. បើក app ដែលបានដំឡើង (ឬចុច **Check for updates**) ។ វាត្រូវតែបង្ហាញ dialog "Update available" ។ ចុច Install ។

## ចំណាំ
- `versionCode` = លេខ run របស់ GitHub Actions ហើយ feed `code` ក៏ជាលេខដូចគ្នា ។ App អាប់ដេតតែពេល `code` នៅក្នុង feed ធំជាង `versionCode` ដែលបានដំឡើង ។
- Feed URL ត្រូវបានបង្កើតដោយស្វ័យប្រវត្តិពី `GITHUB_REPOSITORY` និង branch ពេល build លើ GitHub ។ ពេល build ក្នុងម៉ាស៊ីន ត្រូវកែ `feedRepo` ក្នុង `app/build.gradle` ។
- ការអាប់ដេតតម្រូវឲ្យ APK sign ដោយ key ដូចគ្នា ។ Key សាកល្បង `app/update-test.jks` ត្រូវបាន commit ក្នុង repo ដោយចេតនា (ពាក្យសម្ងាត់ `android`, alias `test`) ។ **កុំប្រើវាសម្រាប់ app ពិតប្រាកដ** ។
- Auto check ដំណើរការពេលបើក app ម្តងរៀងរាល់ ១ នាទី (launcher ពិតប្រើ ៦ ម៉ោង) ។
- ពេលប្រើ Wi-Fi APK ត្រូវបានទាញយកនៅ background មុនបង្ហាញ dialog ។ ពេលប្រើ data dialog បង្ហាញប៊ូតុង "Download and install" ។
- ដំណើរការ workflow ដំបូង Android នឹងសួរសិទ្ធិ "install unknown apps" នៅពេលចុច Install ដំបូង ។
