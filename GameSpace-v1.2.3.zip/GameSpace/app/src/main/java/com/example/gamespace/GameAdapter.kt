package com.example.gamespace

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GameAdapter(
    private val onCardClick: (Int) -> Unit
) : RecyclerView.Adapter<GameAdapter.VH>() {

    private var items: List<GameItem> = emptyList()

    fun submit(list: List<GameItem>) {
        items = list
        notifyDataSetChanged()
    }

    fun getItem(position: Int): GameItem? = items.getOrNull(position)

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_game, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val ctx = holder.itemView.context
        val density = ctx.resources.displayMetrics.density

        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(item.colorA, item.colorB)
        )
        bg.cornerRadius = 22f * density
        bg.setStroke((1.2f * density).toInt().coerceAtLeast(1), 0x55FFFFFF)
        holder.card.background = bg
        holder.card.clipToOutline = true

        holder.name.text = item.label
        holder.badge.setText(
            when (item.kind) {
                ItemKind.GAME -> R.string.badge_game
                ItemKind.APP -> R.string.badge_app
                ItemKind.DEMO -> R.string.badge_demo
            }
        )

        if (item.icon != null) {
            holder.icon.visibility = View.VISIBLE
            holder.icon.setImageDrawable(item.icon)
            holder.letter.visibility = View.GONE
        } else {
            holder.icon.visibility = View.GONE
            holder.letter.visibility = View.VISIBLE
            holder.letter.text = item.label.take(1).uppercase()
        }

        holder.itemView.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onCardClick(p)
        }
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: View = v.findViewById(R.id.card)
        val icon: ImageView = v.findViewById(R.id.ivIcon)
        val letter: TextView = v.findViewById(R.id.tvLetter)
        val name: TextView = v.findViewById(R.id.tvName)
        val badge: TextView = v.findViewById(R.id.tvBadge)
    }
}
