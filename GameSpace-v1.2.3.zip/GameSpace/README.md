# Game Hub — Android GameSpace UI

គម្រោង Android (Kotlin) សម្រាប់ **GameSpace** បែបត្រជាក់ភ្នែក ដូចហ្គេម Free Fire / Mobile Legends៖

- 🔄 **ចូល app ភ្លាម ទូរស័ព្ទបង្វិលទៅផ្ដេក (landscape) ដោយស្វ័យប្រវត្តិ** (`sensorLandscape` ក្នុង `AndroidManifest.xml`) ហើយបង្វិលឆ្វេង-ស្ដាំបាន
- 🖥️ ពេញអេក្រង់ (immersive) លាក់ status bar / navigation bar, គាំទ្រ notch
- 🌊 ផ្ទៃខាងក្រោយ **aurora** ខៀវ-បៃតងទឹកសមុទ្រ (`AuroraBackgroundView.kt`) មានពន្លឺរសាត់ និងភាគល្អិតភ្លឺរលោង
- ⏳ **Splash / Loading** មានរូបទូរស័ព្ទបង្វិល + progress bar ហើយ lobby ស្លាយចូលពីគែម
- 🎴 Carousel កាតហ្គេម (កណ្ដាលធំ/ភ្លឺ, គែមតូច/ស្រអាប់), snap + rung ពេលប្ដូរ
- 📱 ស្កេន **ហ្គេម/កម្មវិធីដែលបានដំឡើងលើទូរស័ព្ទ** ពិតៗ ហើយចុច "ចាប់ផ្ដើមលេង" ដើម្បីបើក
- 🎮 Left rail (ទំព័រដើម / ហ្គេម / ហាង / ការកំណត់) + Right panel + ប៊ូតុង Play មានពន្លឺ pulse

## រចនាសម្ព័ន្ធ
| ឯកសារ | តួនាទី |
|---|---|
| `MainActivity.kt` | splash, carousel, panel, បើកហ្គេម |
| `AuroraBackgroundView.kt` | ផ្ទៃខាងក្រោយ animated |
| `GameAdapter.kt` / `GameItem.kt` | កាតហ្គេម |
| `res/layout/activity_main.xml` | layout ទាំងមូល (landscape) |
| `res/drawable/` | glass panel, ប៊ូតុង, icons |

## Build (តាម GitHub Actions ដូចគម្រោងមុន)
1. Upload ឯកសារទាំងអស់ទៅ GitHub branch `main`
2. ចូលផ្ទាំង **Actions** → រង់ចាំ build → ទាញយក `app-debug-apk` ពី **Artifacts**

## ប្ដូរពណ៌
ពណ៌គ្រឹះនៅ `res/values/colors.xml` និង `AuroraBackgroundView.kt` (បញ្ជី `orbs`) និង `GameItem.kt` (palette កាត)។

---

## 🔔 Update ក្នុង app (v1.1.2)

User មិនចាំបាច់ទាញយក APK ដោយដៃទៀតទេ។ របៀបចេញ update ថ្មី៖

1. បើក `app/build.gradle.kts` ដូរ `val appVersion = "1.1.1"` → `"1.1.2"`
2. Push ទៅ GitHub `main` → GitHub Actions build ហើយចេញ **Release** ថ្មី (`GameSpace.apk`) ដោយស្វ័យប្រវត្តិ
3. ពេល user បើក app វាឃើញ dialog **"មានកំណែថ្មី v1.1.2"** → ចុច **ធ្វើបច្ចុប្បន្នភាព** → app ទាញយក ហើយបើកការដំឡើង

### ការកំណត់ម្ដងគត់
- `res/values/strings.xml` → ដូរ `github_repo` ទៅ `"ឈ្មោះអ្នកប្រើ/ឈ្មោះ-repo"` (repo ត្រូវតែ **public**)
- កុំលុប/ប្ដូរ `app/debug.keystore` — APK ថ្មីត្រូវ sign ដោយ key ដដែល ទើបដំឡើងពីលើ app ចាស់បាន
- ចុចលើអក្សរ `v1.1.2` ក្រោមចំណងជើង ដើម្បីពិនិត្យ update ដោយដៃ
