using System.Runtime.InteropServices;
using System.Text.Json.Nodes;

namespace NokorLauncher.Core;

public static class Rules
{
    public static string OsName => OperatingSystem.IsWindows() ? "windows" : OperatingSystem.IsMacOS() ? "osx" : "linux";
    static string Arch => RuntimeInformation.OSArchitecture switch
    {
        Architecture.X86 => "x86",
        Architecture.Arm64 => "arm64",
        _ => "x86_64",
    };

    public static bool Allow(JsonNode? rules)
    {
        if (rules is not JsonArray arr || arr.Count == 0) return true;
        bool allowed = false;
        foreach (var r in arr)
        {
            bool match = true;
            if (r!["os"] is JsonObject os)
            {
                if ((string?)os["name"] is string n && n != OsName) match = false;
                if ((string?)os["arch"] is string a && a != Arch) match = false;
            }
            // launcher features (demo mode, custom resolution, quick play) are all off
            if (r["features"] is JsonObject f && f.Count > 0) match = false;
            if (match) allowed = (string?)r["action"] == "allow";
        }
        return allowed;
    }
}

public sealed record LibFile(string Path, string? Url, string? Sha1, long Size, bool Extract);

public static class VersionData
{
    /// <summary>Loads versions/&lt;id&gt;/&lt;id&gt;.json and merges "inheritsFrom" (OptiFine, Fabric, Forge...).</summary>
    public static JsonObject Load(string root, string id)
    {
        var path = System.IO.Path.Combine(root, "versions", id, id + ".json");
        var node = JsonNode.Parse(File.ReadAllText(path))!.AsObject();
        var parentId = (string?)node["inheritsFrom"];
        if (parentId == null) { node["_jar"] = id; return node; }

        var merged = Load(root, parentId);
        foreach (var (k, val) in node.ToList())
        {
            if (k == "inheritsFrom") continue;
            if (k == "libraries")
            {
                var libs = new JsonArray();
                foreach (var l in val!.AsArray()) libs.Add(l!.DeepClone());
                foreach (var l in merged["libraries"]!.AsArray()) libs.Add(l!.DeepClone());
                merged["libraries"] = libs;
            }
            else if (k == "arguments") MergeArgs(merged, val!.AsObject());
            else merged[k] = val?.DeepClone();
        }
        return merged;
    }

    static void MergeArgs(JsonObject merged, JsonObject child)
    {
        if (merged["arguments"] is not JsonObject ma) { merged["arguments"] = child.DeepClone(); return; }
        foreach (var key in new[] { "game", "jvm" })
        {
            if (child[key] is not JsonArray ca) continue;
            var arr = ma[key] as JsonArray;
            if (arr == null) { arr = new JsonArray(); ma[key] = arr; }
            foreach (var x in ca) arr.Add(x?.DeepClone());
        }
    }

    public static string MavenPath(string name)
    {
        var ext = "jar";
        var at = name.IndexOf('@');
        if (at >= 0) { ext = name[(at + 1)..]; name = name[..at]; }
        var p = name.Split(':');
        var file = $"{p[1]}-{p[2]}" + (p.Length > 3 ? "-" + p[3] : "") + "." + ext;
        return $"{p[0].Replace('.', '/')}/{p[1]}/{p[2]}/{file}";
    }

    public static IEnumerable<LibFile> Libraries(JsonObject v)
    {
        foreach (var lib in v["libraries"]!.AsArray())
        {
            if (lib == null || !Rules.Allow(lib["rules"])) continue;
            var name = (string)lib["name"]!;
            var dl = lib["downloads"];
            var art = dl?["artifact"];
            if (art != null)
                yield return new LibFile((string)art["path"]!, (string?)art["url"], (string?)art["sha1"], (long?)art["size"] ?? 0, false);
            else if (dl == null && lib["natives"] == null)
            {
                // Maven-style entry without "downloads" (OptiFine, Forge, Fabric)
                var baseUrl = (string?)lib["url"] ?? "https://libraries.minecraft.net/";
                var p = MavenPath(name);
                yield return new LibFile(p, baseUrl.TrimEnd('/') + "/" + p, null, 0, false);
            }

            // legacy natives (before Minecraft 1.19) are extracted from classifier jars
            if (lib["natives"] is JsonObject natives && natives[Rules.OsName] is JsonNode cn)
            {
                var key = ((string)cn!).Replace("${arch}", Environment.Is64BitProcess ? "64" : "32");
                var cls = dl?["classifiers"]?[key];
                if (cls != null)
                    yield return new LibFile((string)cls["path"]!, (string?)cls["url"], (string?)cls["sha1"], (long?)cls["size"] ?? 0, true);
            }
        }
    }
}
