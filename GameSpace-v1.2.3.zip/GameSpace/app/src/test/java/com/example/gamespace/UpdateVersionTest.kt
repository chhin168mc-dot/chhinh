package com.example.gamespace

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UpdateVersionTest {
    @Test
    fun newerVersion_isDetected() {
        assertTrue(UpdateManager.isNewer("1.0.1", "1.0.0"))
        assertTrue(UpdateManager.isNewer("v1.2.0", "1.1.9"))
        assertTrue(UpdateManager.isNewer("2.0", "1.9.9"))
    }

    @Test
    fun sameOrOlder_isNotNewer() {
        assertFalse(UpdateManager.isNewer("1.1.1", "1.1.1"))
        assertFalse(UpdateManager.isNewer("1.0.9", "1.1.0"))
    }
}
