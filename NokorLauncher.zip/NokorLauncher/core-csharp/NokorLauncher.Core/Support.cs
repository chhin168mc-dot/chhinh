using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace NokorLauncher.Core;

/// <summary>One JSON object per line on stdout; the Python UI reads these.</summary>
public static class Out
{
    static readonly object L = new();
    public static void Emit(object o)
    {
        var s = JsonSerializer.Serialize(o);
        lock (L) { Console.Out.WriteLine(s); Console.Out.Flush(); }
    }
}

public static class Cli
{
    public static (string, Dictionary<string, string>) Parse(string[] a)
    {
        var d = new Dictionary<string, string>();
        for (int i = 1; i < a.Length; i++)
            if (a[i].StartsWith("--"))
                d[a[i][2..]] = i + 1 < a.Length && !a[i + 1].StartsWith("--") ? a[++i] : "true";
        return (a.Length > 0 ? a[0] : "", d);
    }
    public static string Req(this Dictionary<string, string> d, string k) =>
        d.TryGetValue(k, out var v) ? v : throw new ArgumentException($"missing --{k}");
}

/// <summary>SHA-1 via the native C library (nokorhash) with a managed fallback.</summary>
public static class Hasher
{
    [DllImport("nokorhash", EntryPoint = "nokor_sha1_file")]
    static extern int NativeSha1([MarshalAs(UnmanagedType.LPUTF8Str)] string path, StringBuilder outHex);

    static bool nativeBroken;

    public static string Sha1File(string path)
    {
        if (!nativeBroken)
        {
            try
            {
                var sb = new StringBuilder(64);
                if (NativeSha1(path, sb) == 0) return sb.ToString();
            }
            catch (Exception e) when (e is DllNotFoundException or EntryPointNotFoundException or BadImageFormatException)
            {
                nativeBroken = true;
            }
        }
        using var fs = File.OpenRead(path);
        return Convert.ToHexString(SHA1.HashData(fs)).ToLowerInvariant();
    }
}

public static class Accounts
{
    /// <summary>Offline account: UUID v3 of "OfflinePlayer:name" (same as the vanilla server).</summary>
    public static JsonObject Offline(string name)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(name, "^[A-Za-z0-9_]{3,16}$"))
            throw new ArgumentException("Name must be 3-16 characters: letters, digits, underscore");
        var h = MD5.HashData(Encoding.UTF8.GetBytes("OfflinePlayer:" + name));
        h[6] = (byte)((h[6] & 0x0f) | 0x30);
        h[8] = (byte)((h[8] & 0x3f) | 0x80);
        return new JsonObject
        {
            ["type"] = "offline",
            ["name"] = name,
            ["uuid"] = Convert.ToHexString(h).ToLowerInvariant(),
            ["accessToken"] = "0",
        };
    }
}
