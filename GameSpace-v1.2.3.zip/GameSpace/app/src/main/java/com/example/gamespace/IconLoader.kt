package com.example.gamespace

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * ផ្ដល់ logo របស់ app:
 * 1) បើបានដំឡើងរួច  → យក icon ពិតពីទូរស័ព្ទ
 * 2) បើមាន cache ក្នុង disk → ប្រើ cache
 * 3) បើមិនទាន់ដំឡើង → ទាញពី iconUrl (store.json) ឬពីទំព័រ Google Play ហើយ cache ទុក
 */
object IconLoader {
    private val memory = LruCache<String, Drawable>(80)
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun installedIcon(ctx: Context, pkg: String): Drawable? =
        try {
            ctx.packageManager.getApplicationIcon(pkg)
        } catch (_: Exception) {
            null
        }

    /** callback ត្រូវបានហៅលើ main thread; បើរក logo មិនឃើញ ផ្ដល់ null */
    fun load(ctx: Context, pkg: String, iconUrl: String?, onLoaded: (Drawable?) -> Unit) {
        val app = ctx.applicationContext
        memory.get(pkg)?.let { onLoaded(it); return }
        installedIcon(app, pkg)?.let {
            memory.put(pkg, it)
            onLoaded(it)
            return
        }
        pool.execute {
            val d = fromDisk(app, pkg) ?: fromNetwork(app, pkg, iconUrl)
            if (d != null) memory.put(pkg, d)
            main.post { onLoaded(d) }
        }
    }

    private fun file(ctx: Context, pkg: String): File {
        val dir = File(ctx.cacheDir, "icons")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "$pkg.png")
    }

    private fun fromDisk(ctx: Context, pkg: String): Drawable? {
        val f = file(ctx, pkg)
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        return BitmapDrawable(ctx.resources, bmp)
    }

    private fun fromNetwork(ctx: Context, pkg: String, iconUrl: String?): Drawable? {
        return try {
            val url = iconUrl ?: scrapePlayIcon(pkg) ?: return null
            val bytes = download(url) ?: return null
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            file(ctx, pkg).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            BitmapDrawable(ctx.resources, bmp)
        } catch (_: Exception) {
            null
        }
    }

    private fun scrapePlayIcon(pkg: String): String? {
        val html = String(
            download("https://play.google.com/store/apps/details?id=$pkg&hl=en") ?: return null,
            Charsets.UTF_8
        )
        val m = Regex("""<meta property="og:image" content="([^"]+)"""").find(html)
            ?: Regex("""<img[^>]+src="(https://play-lh\.googleusercontent\.com/[^"]+)"[^>]*itemprop="image"""").find(html)
            ?: return null
        val raw = m.groupValues[1]
        // ស្នើទំហំ 192px ដើម្បីឲ្យស្រាល
        return if (raw.contains("=")) raw.substringBeforeLast("=") + "=s192" else raw
    }

    private fun download(urlStr: String): ByteArray? {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36")
            if (conn.responseCode != 200) null else conn.inputStream.use { it.readBytes() }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }
}
